import HeaderCustomer from "@/components/customer/HeaderCustomer";

const page = () => {
  return (
    <div className="bg-white-low">
      <HeaderCustomer name="My Wallet" />
      <div className="pb-20 mt-10 px-4">
      </div>
    </div>
  );
};

export default page;
