(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/_3a4912c4._.js",
    "static/chunks/app_globals_73c37791.css"
  ],
  "source": "dynamic"
});
