(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(pannel)_customer_profile_page_jsx_62ea77d0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(pannel)_customer_profile_page_jsx_62ea77d0._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_93f685a6._.js",
    "static/chunks/_caca9c47._.js",
    "static/chunks/node_modules_next_01d5fcbf._.js"
  ],
  "source": "dynamic"
});
