(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(pannel)_customer_shop_[userId]_page_jsx_62ea77d0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(pannel)_customer_shop_[userId]_page_jsx_62ea77d0._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_54b78b0a._.js",
    "static/chunks/_8af4bcaa._.js",
    "static/chunks/node_modules_5fe1cc4c._.js"
  ],
  "source": "dynamic"
});
