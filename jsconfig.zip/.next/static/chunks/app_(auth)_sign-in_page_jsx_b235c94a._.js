(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_sign-in_page_jsx_b235c94a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_sign-in_page_jsx_b235c94a._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_fd189568._.js",
    "static/chunks/node_modules_b4bdca6b._.js",
    "static/chunks/_321dbd1a._.js"
  ],
  "source": "dynamic"
});
