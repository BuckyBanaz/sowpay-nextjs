(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_8af4bcaa._.js", {

"[project]/utils/helper.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "BAISC_DETAILS_FORM": (()=>BAISC_DETAILS_FORM),
    "BEST_SELLER_LIST": (()=>BEST_SELLER_LIST),
    "BOTTOM_BAR_ADMIN_LIST": (()=>BOTTOM_BAR_ADMIN_LIST),
    "BOTTOM_BAR_LIST": (()=>BOTTOM_BAR_LIST),
    "BOTTOM_BAR_SHOPKEPPER_LIST": (()=>BOTTOM_BAR_SHOPKEPPER_LIST),
    "CART_ITEMS": (()=>CART_ITEMS),
    "CATEGORY_LIST": (()=>CATEGORY_LIST),
    "EXCLUSIVE_OFFER_LIST": (()=>EXCLUSIVE_OFFER_LIST),
    "GROSERY_LIST": (()=>GROSERY_LIST),
    "GROSERY_SLIDER_LIST": (()=>GROSERY_SLIDER_LIST),
    "INSTRUCTION_LIST": (()=>INSTRUCTION_LIST),
    "LIST_PRODUCT_FILTER": (()=>LIST_PRODUCT_FILTER),
    "NEARBY_SHOP_LIST": (()=>NEARBY_SHOP_LIST),
    "NOTIFICATION_LIST": (()=>NOTIFICATION_LIST),
    "OFFER_LIST": (()=>OFFER_LIST),
    "SETTING_LIST": (()=>SETTING_LIST),
    "SHOPKEPPER_NOTIFICATION_LIST": (()=>SHOPKEPPER_NOTIFICATION_LIST),
    "SHOPKEPPER_ORDER_FILTER": (()=>SHOPKEPPER_ORDER_FILTER),
    "SHOPKEPPER_ORDER_LIST": (()=>SHOPKEPPER_ORDER_LIST),
    "SHOPKEPPER_PRODUCT_LIST": (()=>SHOPKEPPER_PRODUCT_LIST),
    "TOPBAR_ITEM_LIST": (()=>TOPBAR_ITEM_LIST),
    "TRANSITION_LIST": (()=>TRANSITION_LIST),
    "USER_ADDRESSE_DATA": (()=>USER_ADDRESSE_DATA),
    "USER_PROFILE_DATA": (()=>USER_PROFILE_DATA),
    "VEDIO_LIST": (()=>VEDIO_LIST),
    "userData": (()=>userData)
});
const TOPBAR_ITEM_LIST = [
    {
        image: "/assets/images/png/all.png",
        name: "All",
        url: "/customer/category"
    },
    {
        image: "/assets/images/png/grocery.png",
        name: "Grocery",
        url: "/customer/category"
    },
    {
        image: "/assets/images/png/clothes.png",
        name: "Clothes",
        url: "/customer/category"
    },
    {
        image: "/assets/images/png/medical.png",
        name: "Medical",
        url: "/customer/category"
    },
    {
        image: "/assets/images/png/food.png",
        name: "Food",
        url: "/customer/category"
    }
];
const BEST_SELLER_LIST = [
    {
        image: "/assets/images/png/dairy.png",
        name: "Dairy, Bread & Eggs",
        url: "#"
    },
    {
        image: "/assets/images/png/cold-drink.png",
        name: "Cold Drinks & Juices",
        url: "#"
    },
    {
        image: "/assets/images/png/tea.png",
        name: "Tea, Coffee & More",
        url: "#"
    },
    {
        image: "/assets/images/png/masala.png",
        name: "Masala, Dry Fruits & More",
        url: "#"
    },
    {
        image: "/assets/images/png/munchies.png",
        name: "Munchies",
        url: "#"
    },
    {
        image: "/assets/images/png/sweat-craving.png",
        name: "Sweet Cravings",
        url: "#"
    },
    {
        image: "/assets/images/png/biscut.png",
        name: "Biscuits",
        url: "#"
    },
    {
        image: "/assets/images/png/meat.png",
        name: "Meat, Fish & Eggs",
        url: "#"
    },
    {
        image: "/assets/images/png/packed-food.png",
        name: "Packaged Food",
        url: "#"
    },
    {
        image: "/assets/images/png/break-fast.png",
        name: "Breakfast & Sauces",
        url: "#"
    },
    {
        image: "/assets/images/png/pan-corner.png",
        name: "Pan Corner",
        url: "#"
    },
    {
        image: "/assets/images/png/health-baby.png",
        name: "Health & Baby Care",
        url: "#"
    },
    {
        image: "/assets/images/png/bath.png",
        name: "Bath & Body",
        url: "#"
    },
    {
        image: "/assets/images/png/clean.png",
        name: "Cleaning Essentials",
        url: "#"
    },
    {
        image: "/assets/images/png/home.png",
        name: "Home Needs",
        url: "#"
    },
    {
        image: "/assets/images/png/hygiene.png",
        name: "Hygiene & Groming",
        url: "#"
    }
];
const INSTRUCTION_LIST = [
    {
        title: "Choose Products",
        description: "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit."
    },
    {
        title: "Make Payment",
        description: "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit."
    },
    {
        title: "Get Your Order",
        description: "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit."
    }
];
const OFFER_LIST = [
    {
        image: "/assets/images/png/cart.png",
        name: "Groceries",
        discount: 100
    },
    {
        image: "/assets/images/png/cart.png",
        name: "Home Requirment",
        discount: 400
    },
    {
        image: "/assets/images/png/cart.png",
        name: "Clothes",
        discount: 300
    },
    {
        image: "/assets/images/png/cart.png",
        name: "Medical",
        discount: 200
    }
];
const BOTTOM_BAR_LIST = [
    {
        icon: "home",
        path: "/customer"
    },
    {
        icon: "shop",
        path: "/customer/item-details"
    },
    {
        icon: "wallet",
        path: "#"
    },
    {
        icon: "other",
        path: "/customer/category"
    }
];
const CATEGORY_LIST = [
    {
        image: "/assets/images/png/category/fruits-veg.png",
        path: "/customer/category/fruit-vegetable",
        name: "Fruits & Vegetables"
    },
    {
        image: "/assets/images/png/category/break-fast.png",
        path: "/customer/category/fruit-vegetable",
        name: "Breakfast"
    },
    {
        image: "/assets/images/png/category/beverages-item.png",
        path: "/customer/category/fruit-vegetable",
        name: "Beverages"
    },
    {
        image: "/assets/images/png/category/fish-meat.png",
        path: "/customer/category/fruit-vegetable",
        name: "Meat & Fish"
    },
    {
        image: "/assets/images/png/category/snacks-pack.png",
        path: "/customer/category/fruit-vegetable",
        name: "Snacks"
    },
    {
        image: "/assets/images/png/category/dairy.png",
        path: "/customer/category/fruit-vegetable",
        name: "Dairy"
    },
    {
        image: "/assets/images/png/category/medicalBox.png",
        path: "/customer/category/fruit-vegetable",
        name: "Medical"
    }
];
const NEARBY_SHOP_LIST = [
    {
        image: "/assets/images/png/shop/shop-1.png",
        path: "#",
        name: "Shop Name",
        category: "Category",
        distance: "800 m",
        review: 5
    },
    {
        image: "/assets/images/png/shop/shop-1.png",
        path: "#",
        name: "Shop Name",
        category: "Category",
        distance: "1.2 km",
        review: 5
    },
    {
        image: "/assets/images/png/shop/shop-1.png",
        path: "#",
        name: "Shop Name",
        category: "Category",
        distance: "1.5 km",
        review: 2.9
    },
    {
        image: "/assets/images/png/shop/shop-1.png",
        path: "#",
        name: "Shop Name",
        category: "Category",
        distance: "1.8 km",
        review: 3.6
    },
    {
        image: "/assets/images/png/shop/shop-1.png",
        path: "#",
        name: "Shop Name",
        category: "Category",
        distance: "2.2 km",
        review: 4.5
    },
    {
        image: "/assets/images/png/shop/shop-1.png",
        path: "#",
        name: "Shop Name",
        category: "Category",
        distance: "8.2 km",
        review: 4
    }
];
const NOTIFICATION_LIST = [
    {
        orderId: "345",
        about: "Your Order is Confirmed. Please check everything is okay",
        icon: "checkNotification"
    },
    {
        orderId: "340",
        about: "Your Order is Delivering to your home",
        icon: "deliveringNotification"
    },
    {
        orderId: "344",
        about: "Your Order is Completed. Please  rate the experince",
        icon: "checkNotification"
    },
    {
        orderId: "339",
        about: "Your Order is Confirmed. Please check everything is okay",
        icon: "rateNotification"
    },
    {
        orderId: "345",
        about: "Your Order is Confirmed. Please check everything is okay",
        icon: "checkNotification"
    },
    {
        orderId: "340",
        about: "Your Order is Delivering to your home",
        icon: "deliveringNotification"
    },
    {
        orderId: "344",
        about: "Your Order is Completed. Please  rate the experince",
        icon: "checkNotification"
    },
    {
        orderId: "339",
        about: "Your Order is Confirmed. Please check everything is okay",
        icon: "rateNotification"
    }
];
const LIST_PRODUCT_FILTER = [
    {
        name: "all"
    },
    {
        name: "Vegetables"
    },
    {
        name: "Fruits"
    },
    {
        name: "cooldrinks"
    },
    {
        name: "Masala"
    },
    {
        name: "Vegetables"
    },
    {
        name: "Fruits"
    }
];
const VEDIO_LIST = [
    "/assets/video/sow-pay.mp4",
    "/assets/video/sow-pay.mp4",
    "/assets/video/sow-pay.mp4"
];
const GROSERY_SLIDER_LIST = [
    {
        productName: "Fresh Vegetables",
        offer: "Get Up To 40% off",
        image: "/assets/images/png/growsery/vegetables.png",
        bgImage: "/assets/images/png/growsery/veg-bg.png"
    },
    {
        productName: "Fresh Vegetables",
        offer: "Get Up To 80% off",
        image: "/assets/images/png/growsery/vegetables.png",
        bgImage: "/assets/images/png/growsery/veg-bg.png"
    },
    {
        productName: "Fresh Vegetables",
        offer: "Get Up To 10% off",
        image: "/assets/images/png/growsery/vegetables.png",
        bgImage: "/assets/images/png/growsery/veg-bg.png"
    }
];
const EXCLUSIVE_OFFER_LIST = [
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Red Apple",
        price: 200,
        image: "/assets/images/png/growsery/apple.png",
        amount: "1kg",
        deliveryType: "self"
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Organic Bananas",
        price: 40,
        image: "/assets/images/png/growsery/banana.png",
        amount: "7pcs",
        deliveryType: "self"
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Ginger",
        price: 60,
        image: "/assets/images/png/growsery/ginger.png",
        amount: "250gm",
        deliveryType: "self"
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Bell Pepper Red",
        price: 90,
        image: "/assets/images/png/growsery/pepper-red.png",
        amount: "1kg",
        deliveryType: "self"
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Red Apple",
        price: 200,
        image: "/assets/images/png/growsery/apple.png",
        amount: "1kg",
        deliveryType: "self"
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Organic Bananas",
        price: 40,
        image: "/assets/images/png/growsery/banana.png",
        amount: "7pcs",
        deliveryType: "self"
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Ginger",
        price: 60,
        image: "/assets/images/png/growsery/ginger.png",
        amount: "250gm",
        deliveryType: "self",
        delivery: false
    },
    {
        path: "/customer/category/fruit-vegetable/detaile",
        productName: "Bell Pepper Red",
        price: 90,
        image: "/assets/images/png/growsery/pepper-red.png",
        amount: "1kg",
        deliveryType: "self"
    }
];
const GROSERY_LIST = [
    {
        image: "/assets/images/png/growsery/pulses.png",
        name: "Pulses",
        path: "#"
    },
    {
        image: "/assets/images/png/growsery/rice.png",
        name: "rice",
        path: "#"
    },
    {
        image: "/assets/images/png/growsery/pulses.png",
        name: "Pulses",
        path: "#"
    },
    {
        image: "/assets/images/png/growsery/rice.png",
        name: "rice",
        path: "#"
    },
    {
        image: "/assets/images/png/growsery/pulses.png",
        name: "Pulses",
        path: "#"
    }
];
const SETTING_LIST = [
    {
        icon: "profilePencil",
        name: "Edit Profile",
        path: "/customer/profile/edit-profile"
    },
    {
        icon: "profileLocation",
        name: "My Address",
        path: "/customer/profile/my-address"
    },
    {
        icon: "profileOrder",
        name: "My Orders",
        path: "#"
    },
    {
        icon: "profileChat",
        name: "Chat with us",
        path: "#"
    },
    {
        icon: "profileWallet",
        name: "My Wallet",
        path: "/customer/profile/my-wallet"
    },
    {
        icon: "profileLogout",
        name: "Log out",
        path: "/"
    }
];
const USER_PROFILE_DATA = [
    {
        label: "Name",
        name: "fullName",
        icon: "profileInput",
        type: "text"
    },
    {
        label: "Password",
        name: "password",
        icon: "password",
        type: "password"
    },
    {
        label: "Phone Number",
        name: "number",
        icon: "call",
        type: "number"
    }
];
const USER_ADDRESSE_DATA = [
    {
        label: "Home",
        name: "51/5A, Road: 7, Pallabi, Dhaka",
        icon: "profileInput"
    },
    {
        label: "Work",
        name: "Dingi Technologies Ltd, Wakil T",
        icon: "password"
    }
];
const BAISC_DETAILS_FORM = [
    {
        title: "Basic Information"
    },
    {
        title: "Shop Details"
    },
    {
        title: "Contact & Location"
    }
];
const userData = [
    {
        id: 1,
        name: "User 1",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 2,
        name: "User 2",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 3,
        name: "User 3",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 4,
        name: "User 4",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 5,
        name: "User 5",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 6,
        name: "User 6",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 7,
        name: "User 7",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 8,
        name: "User 8",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 9,
        name: "User 9",
        description: "Jorem ipsum dolor, consectetur."
    },
    {
        id: 10,
        name: "User 10",
        description: "Jorem ipsum dolor, consectetur."
    }
];
const SHOPKEPPER_PRODUCT_LIST = [
    {
        image: "/assets/images/png/shopkepper/product/mama-gold-rice.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/tatashe.png",
        name: "Tatashe",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/ricci-paste.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/rodo.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/mama-gold-rice.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/tatashe.png",
        name: "Tatashe",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/ricci-paste.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/rodo.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/mama-gold-rice.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/tatashe.png",
        name: "Tatashe",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/ricci-paste.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/rodo.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/mama-gold-rice.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/tatashe.png",
        name: "Tatashe",
        amount: 45000,
        inStock: false
    },
    {
        image: "/assets/images/png/shopkepper/product/ricci-paste.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: true
    },
    {
        image: "/assets/images/png/shopkepper/product/rodo.png",
        name: "Mama Gold Rice",
        amount: 45000,
        inStock: false
    }
];
const BOTTOM_BAR_SHOPKEPPER_LIST = [
    {
        icon: "shopkepperCarryBag",
        path: "/shopkepper/order"
    },
    {
        icon: "shopkepperOption",
        path: "/shopkepper/product"
    },
    {
        icon: "shopkepperWallet",
        path: "/shopkepper/wallet"
    },
    {
        icon: "shopkepperChartL",
        path: "#"
    },
    {
        icon: "shopkepperProfile",
        path: "/shopkepper/profile"
    }
];
const BOTTOM_BAR_ADMIN_LIST = [
    {
        icon: "shopkepperCarryBag",
        path: "/admin/user-list"
    },
    {
        icon: "shopkepperOption",
        path: "/admin/payment"
    },
    {
        icon: "shopkepperWallet",
        path: "/shopkepper/wallet"
    },
    {
        icon: "shopkepperChartL",
        path: "#"
    },
    {
        icon: "shopkepperProfile",
        path: "/admin/profile"
    }
];
const SHOPKEPPER_ORDER_FILTER = [
    {
        name: "all"
    },
    {
        name: "New Order"
    },
    {
        name: "Awaiting Pickup"
    },
    {
        name: "In Transit"
    },
    {
        name: "Complete"
    },
    {
        name: "Cancelled"
    }
];
const SHOPKEPPER_ORDER_LIST = [
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Cancelled"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Cancelled"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Cancelled"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    },
    {
        orderId: "#452323",
        time: "Today | 9:00 am",
        item: 3,
        category: "New Order"
    },
    {
        orderId: "#871323",
        time: "Today | 9:00 am",
        item: 3,
        category: "Awaiting Pickup"
    },
    {
        orderId: "#217571",
        time: "Today | 9:00 am",
        item: 3,
        category: "In Transit"
    },
    {
        orderId: "#281723",
        time: "Today | 9:00 am",
        item: 3,
        category: "Complete"
    }
];
const TRANSITION_LIST = [
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    },
    {
        about: "Order Payment",
        orderId: 212323,
        amount: 50000,
        date: "November 25th, 2023"
    }
];
const SHOPKEPPER_NOTIFICATION_LIST = [
    {
        read: true,
        title: "Welcome to mart! 🚀",
        time: "just now",
        diescription: "Lorem ipsum dolor sit amet consectetur. Faucibus nulla lacinia sagittis viverra mauris vel condimentum. Tellus vel scelerisque vitae sagittis et. Posuere feugiat nisl ultricies ut dis ante ipsum. Purus arcu magna aliquam netus sit porta pellentesque pellentesque."
    },
    {
        read: true,
        title: "You've Made a Sale! 💰",
        time: "just now",
        diescription: "Lorem ipsum dolor sit amet consectetur. Faucibus nulla lacinia sagittis viverra mauris vel condimentum. Tellus vel scelerisque vitae sagittis et. Posuere feugiat nisl ultricies ut dis ante ipsum. Purus arcu magna aliquam netus sit porta pellentesque pellentesque."
    },
    {
        read: true,
        title: "Agent En Route to Pick Up Order! 🚗",
        time: "just now",
        diescription: "Lorem ipsum dolor sit amet consectetur. Faucibus nulla lacinia sagittis viverra mauris vel condimentum. Tellus vel scelerisque vitae sagittis et. Posuere feugiat nisl ultricies ut dis ante ipsum. Purus arcu magna aliquam netus sit porta pellentesque pellentesque."
    },
    {
        read: false,
        title: "Success! You've Withdrawn Funds 💸",
        time: "just now",
        diescription: "Lorem ipsum dolor sit amet consectetur. Faucibus nulla lacinia sagittis viverra mauris vel condimentum. Tellus vel scelerisque vitae sagittis et. Posuere feugiat nisl ultricies ut dis ante ipsum. Purus arcu magna aliquam netus sit porta pellentesque pellentesque."
    },
    {
        read: false,
        title: "You've Made a Sale! 💰",
        time: "just now",
        diescription: "Lorem ipsum dolor sit amet consectetur. Faucibus nulla lacinia sagittis viverra mauris vel condimentum. Tellus vel scelerisque vitae sagittis et. Posuere feugiat nisl ultricies ut dis ante ipsum. Purus arcu magna aliquam netus sit porta pellentesque pellentesque."
    }
];
const CART_ITEMS = [
    {
        id: 1,
        name: "Arla DANO Full Cream Milk Powder Instant",
        image: "/assets/images/png/cart/nido.png",
        oldPrice: 200,
        price: 182,
        quantity: 1
    },
    {
        id: 1,
        name: "Arla DANO Full Cream Milk Powder Instant",
        image: "/assets/images/png/cart/nido.png",
        oldPrice: 200,
        price: 182,
        quantity: 1
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/Icons.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
const Icon = ({ icon, className })=>{
    const iconsList = {
        locationNavbar: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "23",
            height: "23",
            viewBox: "0 0 23 23",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M11.4998 1.91666C7.79109 1.91666 4.7915 4.91625 4.7915 8.625C4.7915 12.6212 9.02734 18.1317 10.7715 20.2304C11.1548 20.6904 11.8544 20.6904 12.2378 20.2304C13.9723 18.1317 18.2082 12.6212 18.2082 8.625C18.2082 4.91625 15.2086 1.91666 11.4998 1.91666ZM6.70817 8.625C6.70817 5.98 8.85484 3.83333 11.4998 3.83333C14.1448 3.83333 16.2915 5.98 16.2915 8.625C16.2915 11.385 13.5315 15.5154 11.4998 18.0933C9.5065 15.5346 6.70817 11.3562 6.70817 8.625ZM9.104 8.625C9.104 9.9475 10.1773 11.0208 11.4998 11.0208C12.8223 11.0208 13.8957 9.9475 13.8957 8.625C13.8957 7.3025 12.8223 6.22916 11.4998 6.22916C10.1773 6.22916 9.104 7.3025 9.104 8.625Z",
                    fill: "#01BE62"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("mask", {
                    id: "mask0_209_2129",
                    maskUnits: "userSpaceOnUse",
                    x: "4",
                    y: "1",
                    width: "15",
                    height: "20",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M11.4998 1.91666C7.79109 1.91666 4.7915 4.91625 4.7915 8.625C4.7915 12.6212 9.02734 18.1317 10.7715 20.2304C11.1548 20.6904 11.8544 20.6904 12.2378 20.2304C13.9723 18.1317 18.2082 12.6212 18.2082 8.625C18.2082 4.91625 15.2086 1.91666 11.4998 1.91666ZM6.70817 8.625C6.70817 5.98 8.85484 3.83333 11.4998 3.83333C14.1448 3.83333 16.2915 5.98 16.2915 8.625C16.2915 11.385 13.5315 15.5154 11.4998 18.0933C9.5065 15.5346 6.70817 11.3562 6.70817 8.625ZM9.104 8.625C9.104 9.9475 10.1773 11.0208 11.4998 11.0208C12.8223 11.0208 13.8957 9.9475 13.8957 8.625C13.8957 7.3025 12.8223 6.22916 11.4998 6.22916C10.1773 6.22916 9.104 7.3025 9.104 8.625Z",
                        fill: "white"
                    }, void 0, false, {
                        fileName: "[project]/components/common/Icons.jsx",
                        lineNumber: 27,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    mask: "url(#mask0_209_2129)"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 6,
            columnNumber: 7
        }, this),
        notification: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "21",
            height: "21",
            viewBox: "0 0 21 21",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M5.25 16.625V8.75C5.25 7.35761 5.80312 6.02226 6.78769 5.03769C7.77226 4.05312 9.10761 3.5 10.5 3.5C11.8924 3.5 13.2277 4.05312 14.2123 5.03769C15.1969 6.02226 15.75 7.35761 15.75 8.75V16.625M5.25 16.625H15.75M5.25 16.625H3.5M15.75 16.625H17.5M9.625 19.25H11.375",
                    stroke: "#FF3131",
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M10.5 3.5C10.9832 3.5 11.375 3.10825 11.375 2.625C11.375 2.14175 10.9832 1.75 10.5 1.75C10.0168 1.75 9.625 2.14175 9.625 2.625C9.625 3.10825 10.0168 3.5 10.5 3.5Z",
                    stroke: "#FF3131",
                    strokeWidth: "2"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 38,
            columnNumber: 7
        }, this),
        profile: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "18",
            height: "17",
            viewBox: "0 0 18 17",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M8.5263 0C7.58944 0 6.67362 0.253342 5.89465 0.727988C5.11569 1.20263 4.50855 1.87727 4.15004 2.66658C3.79152 3.45588 3.69771 4.32442 3.88048 5.16234C4.06325 6.00027 4.51439 6.76995 5.17685 7.37406C5.83931 7.97817 6.68333 8.38958 7.60219 8.55625C8.52104 8.72293 9.47346 8.63738 10.339 8.31044C11.2045 7.9835 11.9443 7.42984 12.4648 6.71948C12.9853 6.00912 13.2631 5.17397 13.2631 4.31963C13.2631 3.17399 12.7641 2.07528 11.8757 1.26519C10.9874 0.455102 9.78258 0 8.5263 0ZM8.5263 6.9114C7.96418 6.9114 7.41469 6.7594 6.94731 6.47461C6.47993 6.18982 6.11565 5.78504 5.90054 5.31146C5.68543 4.83787 5.62915 4.31675 5.73881 3.814C5.84847 3.31124 6.11915 2.84943 6.51663 2.48696C6.9141 2.1245 7.42052 1.87766 7.97183 1.77765C8.52314 1.67765 9.0946 1.72897 9.61392 1.92514C10.1332 2.1213 10.5771 2.4535 10.8894 2.87971C11.2017 3.30593 11.3684 3.80702 11.3684 4.31963C11.3684 5.00701 11.069 5.66624 10.536 6.15229C10.003 6.63834 9.28007 6.9114 8.5263 6.9114ZM17.0526 16.4146V15.5507C17.0526 13.9468 16.3539 12.4086 15.1103 11.2744C13.8666 10.1403 12.1798 9.50318 10.421 9.50318H6.63157C4.87276 9.50318 3.186 10.1403 1.94234 11.2744C0.698681 12.4086 0 13.9468 0 15.5507V16.4146H1.89473V15.5507C1.89473 14.405 2.39379 13.3063 3.28212 12.4962C4.17045 11.6861 5.37528 11.231 6.63157 11.231H10.421C11.6773 11.231 12.8821 11.6861 13.7705 12.4962C14.6588 13.3063 15.1579 14.405 15.1579 15.5507V16.4146H17.0526Z",
                fill: "#FF3131"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 67,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 60,
            columnNumber: 7
        }, this),
        mic: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12.0001 13C11.4361 13 10.9617 12.8077 10.5771 12.423C10.1924 12.0383 10.0001 11.564 10.0001 11V5C10.0001 4.436 10.1924 3.96167 10.5771 3.577C10.9617 3.19233 11.4361 3 12.0001 3C12.5641 3 13.0384 3.19233 13.4231 3.577C13.8077 3.96167 14.0001 4.436 14.0001 5V11C14.0001 11.564 13.8077 12.0383 13.4231 12.423C13.0384 12.8077 12.5641 13 12.0001 13ZM11.5001 20V16.983C10.0567 16.8563 8.81806 16.283 7.78406 15.263C6.75006 14.2437 6.16739 12.9977 6.03606 11.525C6.01606 11.3823 6.05272 11.259 6.14606 11.155C6.23939 11.0517 6.35739 11 6.50006 11C6.64272 11 6.76172 11.051 6.85706 11.153C6.95239 11.255 7.01406 11.377 7.04206 11.519C7.17339 12.801 7.71439 13.8683 8.66506 14.721C9.61572 15.5737 10.7274 16 12.0001 16C13.2901 16 14.4061 15.5697 15.3481 14.709C16.2901 13.8477 16.8267 12.7843 16.9581 11.519C16.9861 11.377 17.0477 11.255 17.1431 11.153C17.2384 11.051 17.3574 11 17.5001 11C17.6427 11 17.7607 11.052 17.8541 11.156C17.9474 11.26 17.9841 11.383 17.9641 11.525C17.8327 12.965 17.2544 14.1997 16.2291 15.229C15.2037 16.2583 13.9607 16.843 12.5001 16.983V20C12.5001 20.1427 12.4524 20.2617 12.3571 20.357C12.2617 20.4523 12.1427 20.5 12.0001 20.5C11.8574 20.5 11.7384 20.4523 11.6431 20.357C11.5477 20.2617 11.5001 20.1427 11.5001 20Z",
                fill: "#383838"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 81,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 74,
            columnNumber: 7
        }, this),
        filter: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "9.66162",
                    cy: "7.45795",
                    r: "3.3",
                    stroke: "#181725",
                    strokeWidth: "1.9"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: "3.89199",
                    y: "6.41642",
                    width: "3.30802",
                    height: "2.08304",
                    rx: "1.04152",
                    fill: "#181725",
                    stroke: "#181725",
                    strokeWidth: "0.3"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "15.3184",
                    cy: "16.8067",
                    r: "3.3",
                    transform: "rotate(-180 15.3184 16.8067)",
                    stroke: "#181725",
                    strokeWidth: "1.9"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: "12.8339",
                    y: "6.41641",
                    width: "7.83623",
                    height: "2.08304",
                    rx: "1.04152",
                    fill: "#181725",
                    stroke: "#181725",
                    strokeWidth: "0.3"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 120,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: "12.1461",
                    y: "17.8482",
                    width: "7.84",
                    height: "2.08304",
                    rx: "1.04152",
                    transform: "rotate(-180 12.1461 17.8482)",
                    fill: "#181725",
                    stroke: "#181725",
                    strokeWidth: "0.3"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 130,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: "20.9947",
                    y: "17.8482",
                    width: "2.84148",
                    height: "2.08304",
                    rx: "1.04152",
                    transform: "rotate(-180 20.9947 17.8482)",
                    fill: "#181725",
                    stroke: "#181725",
                    strokeWidth: "0.3"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 141,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 88,
            columnNumber: 7
        }, this),
        seeMore: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "8",
            height: "12",
            viewBox: "0 0 8 12",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M-4.59555e-07 1.4866L4.5134 6L-6.49811e-08 10.5134L1.48659 12L7.48659 6L1.48659 -1.01866e-06L-4.59555e-07 1.4866Z",
                fill: "#FF3131"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 162,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 155,
            columnNumber: 7
        }, this),
        play: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M5.66895 4.76001C5.69596 4.53295 5.77556 4.31532 5.90143 4.12442C6.0273 3.93352 6.19597 3.77462 6.39403 3.66035C6.59209 3.54608 6.81408 3.47959 7.04234 3.46616C7.27061 3.45273 7.49886 3.49274 7.70895 3.58301C8.77095 4.03701 11.1509 5.11601 14.1709 6.85901C17.1919 8.60301 19.3169 10.126 20.2399 10.817C21.0279 11.408 21.0299 12.58 20.2409 13.173C19.3269 13.86 17.2279 15.363 14.1709 17.129C11.1109 18.895 8.75895 19.961 7.70695 20.409C6.80095 20.796 5.78695 20.209 5.66895 19.232C5.53095 18.09 5.27295 15.497 5.27295 11.995C5.27295 8.49501 5.52995 5.90301 5.66895 4.76001Z",
                fill: "#01BE62"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 176,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 169,
            columnNumber: 7
        }, this),
        back: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "32",
            height: "33",
            className: className,
            viewBox: "0 0 32 33",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20.546 22.6249L14.4393 16.5049L20.546 10.3849L18.666 8.50488L10.666 16.5049L18.666 24.5049L20.546 22.6249Z",
                fill: "black"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 193,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 185,
            columnNumber: 7
        }, this),
        locationWhite: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "25",
            viewBox: "0 0 24 25",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12 22.5049C11.7667 22.5049 11.5667 22.4382 11.4 22.3049C11.2333 22.1716 11.1083 21.9965 11.025 21.7799C10.7083 20.8465 10.3083 19.9715 9.825 19.1549C9.35833 18.3382 8.7 17.3799 7.85 16.2799C7 15.1799 6.30833 14.1299 5.775 13.1299C5.25833 12.1299 5 10.9215 5 9.50488C5 7.55488 5.675 5.90488 7.025 4.55488C8.39167 3.18822 10.05 2.50488 12 2.50488C13.95 2.50488 15.6 3.18822 16.95 4.55488C18.3167 5.90488 19 7.55488 19 9.50488C19 11.0215 18.7083 12.2882 18.125 13.3049C17.5583 14.3049 16.9 15.2965 16.15 16.2799C15.25 17.4799 14.5667 18.4799 14.1 19.2799C13.65 20.0632 13.275 20.8965 12.975 21.7799C12.8917 22.0132 12.7583 22.1966 12.575 22.3299C12.4083 22.4466 12.2167 22.5049 12 22.5049ZM12 12.0049C12.7 12.0049 13.2917 11.7632 13.775 11.2799C14.2583 10.7965 14.5 10.2049 14.5 9.50488C14.5 8.80488 14.2583 8.21322 13.775 7.72988C13.2917 7.24655 12.7 7.00488 12 7.00488C11.3 7.00488 10.7083 7.24655 10.225 7.72988C9.74167 8.21322 9.5 8.80488 9.5 9.50488C9.5 10.2049 9.74167 10.7965 10.225 11.2799C10.7083 11.7632 11.3 12.0049 12 12.0049Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 207,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 200,
            columnNumber: 7
        }, this),
        home: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "25",
            viewBox: "0 0 24 25",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M3.75 10.4424V21.5049C3.75 21.7038 3.82902 21.8946 3.96967 22.0352C4.11032 22.1759 4.30109 22.2549 4.5 22.2549H9V15.8799C9 15.5815 9.11853 15.2954 9.3295 15.0844C9.54048 14.8734 9.82663 14.7549 10.125 14.7549H13.875C14.1734 14.7549 14.4595 14.8734 14.6705 15.0844C14.8815 15.2954 15 15.5815 15 15.8799V22.2549H19.5C19.6989 22.2549 19.8897 22.1759 20.0303 22.0352C20.171 21.8946 20.25 21.7038 20.25 21.5049V10.4424",
                    stroke: "currentColor",
                    strokeWidth: "1.54",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 221,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M22.5 12.505L12.5105 2.94254C12.2761 2.69504 11.7281 2.69223 11.4895 2.94254L1.5 12.505M18.75 8.89567V3.50504H16.5V6.73942",
                    stroke: "currentColor",
                    strokeWidth: "1.54",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 228,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 214,
            columnNumber: 7
        }, this),
        shop: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "25",
            viewBox: "0 0 24 25",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M8 12.5049V8.50488C8 7.44402 8.42143 6.4266 9.17157 5.67646C9.92172 4.92631 10.9391 4.50488 12 4.50488C13.0609 4.50488 14.0783 4.92631 14.8284 5.67646C15.5786 6.4266 16 7.44402 16 8.50488V12.5049",
                    stroke: "currentColor",
                    strokeWidth: "1.75",
                    strokeLinecap: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 245,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M3.69461 13.1729C3.83961 11.4319 3.91261 10.5619 4.48661 10.0329C5.06061 9.50388 5.93461 9.50488 7.68161 9.50488H16.3206C18.0666 9.50488 18.9406 9.50488 19.5146 10.0329C20.0886 10.5609 20.1616 11.4319 20.3066 13.1729L20.8206 19.3389C20.9046 20.3519 20.9466 20.8589 20.6506 21.1819C20.3526 21.5049 19.8446 21.5049 18.8266 21.5049H5.1746C4.1576 21.5049 3.64861 21.5049 3.35161 21.1819C3.05461 20.8589 3.09661 20.3519 3.18161 19.3389L3.69461 13.1729Z",
                    stroke: "currentColor",
                    strokeWidth: "1.75"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 251,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 238,
            columnNumber: 7
        }, this),
        scaner: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "25",
            viewBox: "0 0 24 25",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20 12.5049H4M16 4.50488H18C18.5304 4.50488 19.0391 4.7156 19.4142 5.09067C19.7893 5.46574 20 5.97445 20 6.50488V8.50488M8 20.5049H6C5.46957 20.5049 4.96086 20.2942 4.58579 19.9191C4.21071 19.544 4 19.0353 4 18.5049V16.5049M20 16.5049V18.5049C20 19.0353 19.7893 19.544 19.4142 19.9191C19.0391 20.2942 18.5304 20.5049 18 20.5049H16M4 8.50488V6.50488C4 5.97445 4.21071 5.46574 4.58579 5.09067C4.96086 4.7156 5.46957 4.50488 6 4.50488H8",
                stroke: "currentColor",
                strokeWidth: "2",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 266,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 259,
            columnNumber: 7
        }, this),
        wallet: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "25",
            viewBox: "0 0 24 25",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M19 12.5049C19 12.7701 18.8946 13.0245 18.7071 13.212C18.5196 13.3995 18.2652 13.5049 18 13.5049C17.7348 13.5049 17.4804 13.3995 17.2929 13.212C17.1054 13.0245 17 12.7701 17 12.5049C17 12.2397 17.1054 11.9853 17.2929 11.7978C17.4804 11.6102 17.7348 11.5049 18 11.5049C18.2652 11.5049 18.5196 11.6102 18.7071 11.7978C18.8946 11.9853 19 12.2397 19 12.5049Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 283,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M9.944 3.75488H13.056C14.894 3.75488 16.35 3.75488 17.489 3.90788C18.661 4.06588 19.61 4.39788 20.359 5.14588C21.283 6.07088 21.578 7.30888 21.685 8.91588C22.262 9.16888 22.698 9.70588 22.745 10.3859C22.75 10.4469 22.75 10.5119 22.75 10.5719V14.4379C22.75 14.4979 22.75 14.5629 22.746 14.6229C22.698 15.3029 22.262 15.8409 21.685 16.0949C21.578 17.7009 21.283 18.9389 20.359 19.8639C19.61 20.6119 18.661 20.9439 17.489 21.1019C16.349 21.2549 14.894 21.2549 13.056 21.2549H9.944C8.106 21.2549 6.65 21.2549 5.511 21.1019C4.339 20.9439 3.39 20.6119 2.641 19.8639C1.893 19.1149 1.561 18.1659 1.403 16.9939C1.25 15.8539 1.25 14.3989 1.25 12.5609V12.4489C1.25 10.6109 1.25 9.15488 1.403 8.01588C1.561 6.84388 1.893 5.89488 2.641 5.14588C3.39 4.39788 4.339 4.06588 5.511 3.90788C6.651 3.75488 8.106 3.75488 9.944 3.75488ZM20.168 16.2549H18.23C16.085 16.2549 14.249 14.6269 14.249 12.5049C14.249 10.3829 16.085 8.75488 18.229 8.75488H20.167C20.053 7.41388 19.796 6.70488 19.297 6.20688C18.874 5.78388 18.294 5.52988 17.288 5.39488C16.261 5.25688 14.906 5.25488 12.999 5.25488H9.999C8.092 5.25488 6.738 5.25688 5.709 5.39488C4.704 5.52988 4.124 5.78388 3.701 6.20688C3.278 6.62988 3.025 7.20988 2.89 8.21488C2.752 9.24288 2.75 10.5969 2.75 12.5039C2.75 14.4109 2.752 15.7659 2.89 16.7939C3.025 17.7989 3.279 18.3789 3.702 18.8019C4.125 19.2249 4.705 19.4789 5.711 19.6139C6.739 19.7519 8.093 19.7539 10 19.7539H13C14.907 19.7539 16.262 19.7519 17.29 19.6139C18.295 19.4789 18.875 19.2249 19.298 18.8019C19.797 18.3039 20.054 17.5959 20.168 16.2539M5.25 8.50488C5.25 8.30597 5.32902 8.1152 5.46967 7.97455C5.61032 7.8339 5.80109 7.75488 6 7.75488H10C10.1989 7.75488 10.3897 7.8339 10.5303 7.97455C10.671 8.1152 10.75 8.30597 10.75 8.50488C10.75 8.70379 10.671 8.89456 10.5303 9.03521C10.3897 9.17586 10.1989 9.25488 10 9.25488H6C5.80109 9.25488 5.61032 9.17586 5.46967 9.03521C5.32902 8.89456 5.25 8.70379 5.25 8.50488ZM20.924 10.2549H18.23C16.806 10.2549 15.749 11.3139 15.749 12.5049C15.749 13.6959 16.806 14.7549 18.229 14.7549H20.947C21.153 14.7419 21.242 14.6029 21.249 14.5189V10.4909C21.242 10.4069 21.153 10.2679 20.947 10.2559L20.924 10.2549Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 287,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 276,
            columnNumber: 7
        }, this),
        other: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "25",
            viewBox: "0 0 24 25",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M17 10.5049C18.6569 10.5049 20 9.16174 20 7.50488C20 5.84803 18.6569 4.50488 17 4.50488C15.3431 4.50488 14 5.84803 14 7.50488C14 9.16174 15.3431 10.5049 17 10.5049Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 303,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M7 20.5049C8.65685 20.5049 10 19.1617 10 17.5049C10 15.848 8.65685 14.5049 7 14.5049C5.34315 14.5049 4 15.848 4 17.5049C4 19.1617 5.34315 20.5049 7 20.5049Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 310,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M14 14.5049H20V19.5049C20 19.7701 19.8946 20.0245 19.7071 20.212C19.5196 20.3995 19.2652 20.5049 19 20.5049H15C14.7348 20.5049 14.4804 20.3995 14.2929 20.212C14.1054 20.0245 14 19.7701 14 19.5049V14.5049ZM4 4.50488H10V9.50488C10 9.7701 9.89464 10.0245 9.70711 10.212C9.51957 10.3995 9.26522 10.5049 9 10.5049H5C4.73478 10.5049 4.48043 10.3995 4.29289 10.212C4.10536 10.0245 4 9.7701 4 9.50488V4.50488Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 317,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 296,
            columnNumber: 7
        }, this),
        star: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "13",
            height: "12",
            viewBox: "0 0 13 12",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6.5 0L7.95934 4.49139H12.6819L8.86126 7.26722L10.3206 11.7586L6.5 8.98278L2.6794 11.7586L4.13874 7.26722L0.318133 4.49139H5.04066L6.5 0Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 334,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 327,
            columnNumber: 7
        }, this),
        checkNotification: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "36",
            viewBox: "0 0 36 36",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "18",
                    r: "18",
                    fill: "#F37A20"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 348,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M12.5413 14.9584C12.1518 14.9584 11.833 14.6397 11.833 14.2501C11.833 13.8605 12.1518 13.5417 12.5413 13.5417H22.458C22.8476 13.5417 23.1663 13.8605 23.1663 14.2501C23.1663 14.6397 22.8476 14.9584 22.458 14.9584H12.5413ZM12.5413 16.3751H22.458C22.8476 16.3751 23.1663 16.6938 23.1663 17.0834C23.1663 17.473 22.8476 17.7917 22.458 17.7917H12.5413C12.1518 17.7917 11.833 17.473 11.833 17.0834C11.833 16.6938 12.1518 16.3751 12.5413 16.3751ZM12.5413 22.0417H18.208C18.5976 22.0417 18.9163 22.3605 18.9163 22.7501C18.9163 23.1397 18.5976 23.4584 18.208 23.4584H12.5413C12.1518 23.4584 11.833 23.1397 11.833 22.7501C11.833 22.3605 12.1518 22.0417 12.5413 22.0417ZM12.5413 20.6251H22.458C22.8476 20.6251 23.1663 20.3063 23.1663 19.9167C23.1663 19.5272 22.8476 19.2084 22.458 19.2084H12.5413C12.1518 19.2084 11.833 19.5272 11.833 19.9167C11.833 20.3063 12.1518 20.6251 12.5413 20.6251Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 349,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 341,
            columnNumber: 7
        }, this),
        deliveringNotification: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "36",
            viewBox: "0 0 36 36",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "18",
                    r: "18",
                    fill: "#36B37E"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 365,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M22.6026 20.8021L20.8034 20.5967C20.3714 20.5471 19.9464 20.6958 19.6418 21.0004L18.3384 22.3038C16.3339 21.2837 14.6905 19.6475 13.6705 17.6358L14.9809 16.3254C15.2855 16.0208 15.4343 15.5958 15.3847 15.1637L15.1793 13.3787C15.0943 12.6633 14.4922 12.125 13.7697 12.125H12.5443C11.7439 12.125 11.078 12.7908 11.1276 13.5912C11.503 19.6404 16.3409 24.4712 22.383 24.8467C23.1834 24.8962 23.8493 24.2304 23.8493 23.43V22.2046C23.8564 21.4892 23.318 20.8871 22.6026 20.8021ZM13.6325 13.5417C13.675 14.1721 13.7812 14.7883 13.9513 15.3763L13.1013 16.2263C12.8108 15.3763 12.6267 14.4767 12.5629 13.5417H13.6325ZM22.4583 22.3746C21.835 22.3321 21.2188 22.2258 20.6167 22.0558L19.7667 22.8988C20.6237 23.1821 21.5233 23.3663 22.4583 23.43V22.3746Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 366,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 358,
            columnNumber: 7
        }, this),
        rateNotification: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "36",
            viewBox: "0 0 36 36",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "18",
                    r: "18",
                    fill: "#36B37E"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 382,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M22.6026 20.8021L20.8034 20.5967C20.3714 20.5471 19.9464 20.6958 19.6418 21.0004L18.3384 22.3038C16.3339 21.2837 14.6905 19.6475 13.6705 17.6358L14.9809 16.3254C15.2855 16.0208 15.4343 15.5958 15.3847 15.1637L15.1793 13.3787C15.0943 12.6633 14.4922 12.125 13.7697 12.125H12.5443C11.7439 12.125 11.078 12.7908 11.1276 13.5912C11.503 19.6404 16.3409 24.4712 22.383 24.8467C23.1834 24.8962 23.8493 24.2304 23.8493 23.43V22.2046C23.8564 21.4892 23.318 20.8871 22.6026 20.8021ZM13.6325 13.5417C13.675 14.1721 13.7812 14.7883 13.9513 15.3763L13.1013 16.2263C12.8108 15.3763 12.6267 14.4767 12.5629 13.5417H13.6325ZM22.4583 22.3746C21.835 22.3321 21.2188 22.2258 20.6167 22.0558L19.7667 22.8988C20.6237 23.1821 21.5233 23.3663 22.4583 23.43V22.3746Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 383,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 375,
            columnNumber: 7
        }, this),
        plus: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "12",
            height: "12",
            viewBox: "0 0 18 18",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M18 9C18 9.39794 17.8474 9.78261 17.5621 10.0612C17.2835 10.3464 16.8986 10.5055 16.5006 10.5055H10.5028V16.5011C10.5028 16.899 10.3435 17.2837 10.0582 17.5623C9.77958 17.8408 9.4014 18 9.00332 18C8.60523 18 8.22042 17.8408 7.94176 17.5623C7.65647 17.2837 7.49724 16.899 7.49724 16.5011V10.5055H1.49945C1.10136 10.5055 0.71655 10.3464 0.437892 10.0612C0.159233 9.78261 0 9.39794 0 9C0 8.60206 0.159233 8.22402 0.437892 7.93884C0.71655 7.66028 1.10136 7.50111 1.49945 7.50111H7.49724V1.50553C7.49724 1.10759 7.65647 0.722918 7.94176 0.444363C8.22042 0.159175 8.60523 0 9.00332 0C9.4014 0 9.77958 0.159175 10.0582 0.444363C10.3435 0.722918 10.5028 1.10759 10.5028 1.50553V7.50111H16.5006C16.8986 7.50111 17.2835 7.66028 17.5621 7.93884C17.8474 8.22402 18 8.60206 18 9Z",
                fill: "white"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 399,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 392,
            columnNumber: 7
        }, this),
        profilePencil: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M20.71 7.04249C21.1 6.65249 21.1 6.02249 20.71 5.63249L18.37 3.29249C18.1832 3.10523 17.9295 3 17.665 3C17.4005 3 17.1468 3.10523 16.96 3.29249L15.13 5.12249L18.88 8.87249L20.71 7.04249ZM3 17.4625V20.5025C3 20.7825 3.22 21.0025 3.5 21.0025H6.54C6.67 21.0025 6.8 20.9525 6.89 20.8525L17.81 9.94249L14.06 6.19249L3.15 17.1025C3.05 17.2025 3 17.3225 3 17.4625ZM14.98 9.94L14.06 9.02L5 18.08V19H5.92L14.98 9.94Z",
                fill: "#236CD9"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 413,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 406,
            columnNumber: 7
        }, this),
        profileLocation: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M12 2C8.13 2 5 5.13 5 9C5 13.17 9.42 18.92 11.24 21.11C11.64 21.59 12.37 21.59 12.77 21.11C14.58 18.92 19 13.17 19 9C19 5.13 15.87 2 12 2ZM7 9C7 6.24 9.24 4 12 4C14.76 4 17 6.24 17 9C17 11.88 14.12 16.19 12 18.88C9.92 16.21 7 11.85 7 9ZM9.5 9C9.5 10.38 10.62 11.5 12 11.5C13.38 11.5 14.5 10.38 14.5 9C14.5 7.62 13.38 6.5 12 6.5C10.62 6.5 9.5 7.62 9.5 9Z",
                fill: "#37474F"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 429,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 422,
            columnNumber: 7
        }, this),
        profileOrder: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M17.21 9.98H22C22.55 9.98 23 10.43 23 10.98L22.97 11.25L20.43 20.52C20.19 21.36 19.42 21.98 18.5 21.98H5.5C4.58 21.98 3.81 21.36 3.58 20.52L1.04 11.25C1.01 11.16 1 11.07 1 10.98C1 10.43 1.45 9.98 2 9.98H6.79L11.17 3.43C11.36 3.14 11.68 3 12 3C12.32 3 12.64 3.14 12.83 3.42L17.21 9.98ZM14.8 9.98L12 5.78L9.2 9.98H14.8ZM18.5 19.98L5.51 19.99L3.31 11.98H20.7L18.5 19.98ZM10 15.98C10 14.88 10.9 13.98 12 13.98C13.1 13.98 14 14.88 14 15.98C14 17.08 13.1 17.98 12 17.98C10.9 17.98 10 17.08 10 15.98Z",
                fill: "#37474F"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 445,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 438,
            columnNumber: 7
        }, this),
        profileWishList: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M10.9072 14.7557V21.2157C10.9072 22.0427 12.0151 22.308 12.3896 21.559L17.9445 10.4491C18.1942 9.93414 17.8197 9.32559 17.2424 9.32559H13.279V2.78757C13.279 1.96057 12.1711 1.69531 11.8122 2.42869L6.07002 13.6166C5.78915 14.1316 6.17924 14.7557 6.75659 14.7557H10.9072ZM15.2704 11.3256L12.9072 16.0517V12.7557H8.75933L11.279 7.8471V11.3256H15.2704Z",
                fill: "#37474F"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 461,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 454,
            columnNumber: 7
        }, this),
        profileChat: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M4 2H20C21.1 2 22 2.9 22 4V16C22 17.1 21.1 18 20 18H6L2 22V4C2 2.9 2.9 2 4 2ZM6 16H19C19.55 16 20 15.55 20 15V5C20 4.45 19.55 4 19 4H5C4.45 4 4 4.45 4 5V18L6 16Z",
                fill: "#5EC401"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 477,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 470,
            columnNumber: 7
        }, this),
        profileWallet: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M6 8H10",
                    stroke: "#01BE62",
                    strokeWidth: "1.65",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 493,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M20.833 9H18.231C16.446 9 15 10.343 15 12C15 13.657 16.447 15 18.23 15H20.833C20.917 15 20.958 15 20.993 14.998C21.533 14.965 21.963 14.566 21.998 14.065C22 14.033 22 13.994 22 13.917V10.083C22 10.006 22 9.967 21.998 9.935C21.962 9.434 21.533 9.035 20.993 9.002C20.959 9 20.917 9 20.833 9Z",
                    stroke: "#01BE62",
                    strokeWidth: "1.65"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 500,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M20.965 9C20.887 7.128 20.637 5.98 19.828 5.172C18.657 4 16.771 4 13 4H10C6.229 4 4.343 4 3.172 5.172C2.001 6.344 2 8.229 2 12C2 15.771 2 17.657 3.172 18.828C4.344 19.999 6.229 20 10 20H13C16.771 20 18.657 20 19.828 18.828C20.637 18.02 20.888 16.872 20.965 15",
                    stroke: "#01BE62",
                    strokeWidth: "1.65"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 505,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M17.991 12H18.001",
                    stroke: "#01BE62",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 510,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 486,
            columnNumber: 7
        }, this),
        profileLogout: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M11.0019 4.00293C11.0019 3.45293 11.4519 3.00293 12.0019 3.00293C12.5519 3.00293 13.0019 3.45293 13.0019 4.00293V12.0029C13.0019 12.5529 12.5519 13.0029 12.0019 13.0029C11.4519 13.0029 11.0019 12.5529 11.0019 12.0029V4.00293ZM17.1319 7.25293C16.7619 6.86293 16.7519 6.25293 17.1419 5.86293C17.5419 5.46293 18.2019 5.47293 18.5819 5.88293C20.0819 7.48293 21.0019 9.62293 21.0019 11.9929C21.0019 17.0629 16.8119 21.1529 11.7119 20.9929C6.83188 20.8429 2.86188 16.6229 3.00188 11.7429C3.07188 9.47293 3.98188 7.42293 5.43188 5.88293C5.81188 5.47293 6.46188 5.46293 6.86188 5.86293C7.24188 6.24293 7.24188 6.85293 6.87188 7.24293C5.71188 8.49293 5.00188 10.1629 5.00188 12.0029C5.00188 15.9029 8.18188 19.0529 12.0919 18.9929C15.9219 18.9529 19.0919 15.6529 19.0019 11.8229C18.9619 10.0529 18.2619 8.45293 17.1319 7.25293Z",
                fill: "#FF5552"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 526,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 519,
            columnNumber: 7
        }, this),
        camera: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "18",
            height: "18",
            viewBox: "0 0 18 18",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M12.6225 3.75H15C15.825 3.75 16.5 4.425 16.5 5.25V14.25C16.5 15.075 15.825 15.75 15 15.75H3C2.175 15.75 1.5 15.075 1.5 14.25V5.25C1.5 4.425 2.175 3.75 3 3.75H5.3775L6.75 2.25H11.25L12.6225 3.75ZM3 14.25H15V5.25H11.9625L10.59 3.75H7.41L6.0375 5.25H3V14.25ZM9 6C6.93 6 5.25 7.68 5.25 9.75C5.25 11.82 6.93 13.5 9 13.5C11.07 13.5 12.75 11.82 12.75 9.75C12.75 7.68 11.07 6 9 6ZM6.75 9.75C6.75 10.9875 7.7625 12 9 12C10.2375 12 11.25 10.9875 11.25 9.75C11.25 8.5125 10.2375 7.5 9 7.5C7.7625 7.5 6.75 8.5125 6.75 9.75Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 542,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 535,
            columnNumber: 7
        }, this),
        profileInput: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM7.07 18.28C7.5 17.38 10.12 16.5 12 16.5C13.88 16.5 16.51 17.38 16.93 18.28C15.57 19.36 13.86 20 12 20C10.14 20 8.43 19.36 7.07 18.28ZM12 14.5C13.46 14.5 16.93 15.09 18.36 16.83C19.38 15.49 20 13.82 20 12C20 7.59 16.41 4 12 4C7.59 4 4 7.59 4 12C4 13.82 4.62 15.49 5.64 16.83C7.07 15.09 10.54 14.5 12 14.5ZM12 6C10.06 6 8.5 7.56 8.5 9.5C8.5 11.44 10.06 13 12 13C13.94 13 15.5 11.44 15.5 9.5C15.5 7.56 13.94 6 12 6ZM10.5 9.5C10.5 10.33 11.17 11 12 11C12.83 11 13.5 10.33 13.5 9.5C13.5 8.67 12.83 8 12 8C11.17 8 10.5 8.67 10.5 9.5Z",
                fill: "#575C57"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 558,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 551,
            columnNumber: 7
        }, this),
        password: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "16",
            height: "22",
            viewBox: "0 0 16 22",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M13 7.5H14C15.1 7.5 16 8.4 16 9.5V19.5C16 20.6 15.1 21.5 14 21.5H2C0.9 21.5 0 20.6 0 19.5V9.5C0 8.4 0.9 7.5 2 7.5H3V5.5C3 2.74 5.24 0.5 8 0.5C10.76 0.5 13 2.74 13 5.5V7.5ZM8 2.5C6.34 2.5 5 3.84 5 5.5V7.5H11V5.5C11 3.84 9.66 2.5 8 2.5ZM2 19.5V9.5H14V19.5H2ZM10 14.5C10 15.6 9.1 16.5 8 16.5C6.9 16.5 6 15.6 6 14.5C6 13.4 6.9 12.5 8 12.5C9.1 12.5 10 13.4 10 14.5Z",
                fill: "#575C57"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 574,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 567,
            columnNumber: 7
        }, this),
        call: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "18",
            height: "18",
            viewBox: "0 0 18 18",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M16.2037 12.25L13.6637 11.96C13.0537 11.89 12.4537 12.1 12.0237 12.53L10.1837 14.37C7.35367 12.93 5.03367 10.62 3.59367 7.78L5.44367 5.93C5.87367 5.5 6.08367 4.9 6.01367 4.29L5.72367 1.77C5.60367 0.76 4.75367 0 3.73367 0H2.00367C0.873674 0 -0.0663265 0.94 0.00367348 2.07C0.533673 10.61 7.36367 17.43 15.8937 17.96C17.0237 18.03 17.9637 17.09 17.9637 15.96V14.23C17.9737 13.22 17.2137 12.37 16.2037 12.25ZM3.54 2C3.6 2.89 3.75 3.76 3.99 4.59L2.79 5.79C2.38 4.59 2.12 3.32 2.03 2H3.54ZM16 14.47C15.12 14.41 14.25 14.26 13.4 14.02L12.2 15.21C13.41 15.61 14.68 15.87 16 15.96V14.47Z",
                fill: "#575C57"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 590,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 583,
            columnNumber: 7
        }, this),
        eyeOpen: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M1 12.5C2.73 8.11 7 5 12 5C17 5 21.27 8.11 23 12.5C21.27 16.89 17 20 12 20C7 20 2.73 16.89 1 12.5ZM12 7C15.79 7 19.17 9.13 20.82 12.5C19.17 15.87 15.79 18 12 18C8.21 18 4.83 15.87 3.18 12.5C4.83 9.13 8.21 7 12 7ZM7.5 12.5C7.5 10.02 9.52 8 12 8C14.48 8 16.5 10.02 16.5 12.5C16.5 14.98 14.48 17 12 17C9.52 17 7.5 14.98 7.5 12.5ZM14.5 12.5C14.5 11.12 13.38 10 12 10C10.62 10 9.5 11.12 9.5 12.5C9.5 13.88 10.62 15 12 15C13.38 15 14.5 13.88 14.5 12.5Z",
                fill: "#575C57"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 606,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 599,
            columnNumber: 7
        }, this),
        pencilAddresse: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "36",
            viewBox: "0 0 36 36",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "18",
                    r: "18",
                    fill: "#01BE62"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 622,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M25.1272 13.7616C25.4463 13.4425 25.4463 12.927 25.1272 12.608L23.2127 10.6934C23.0598 10.5402 22.8523 10.4541 22.6358 10.4541C22.4194 10.4541 22.2119 10.5402 22.059 10.6934L20.5618 12.1907L23.6299 15.2589L25.1272 13.7616ZM10.6372 22.287V24.7743C10.6372 25.0034 10.8172 25.1834 11.0463 25.1834H13.5336C13.6399 25.1834 13.7463 25.1425 13.8199 25.0607L22.7545 16.1343L19.6863 13.0661L10.7599 21.9925C10.6781 22.0743 10.6372 22.1725 10.6372 22.287ZM20.439 16.1323L19.6863 15.3796L12.2736 22.7923V23.545H13.0263L20.439 16.1323Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 623,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 615,
            columnNumber: 7
        }, this),
        deleteAddresse: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "36",
            viewBox: "0 0 36 36",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "18",
                    cy: "18",
                    r: "18",
                    fill: "#FF3131"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 639,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M20.2834 10.6914L20.8643 11.2723H22.9098C23.3598 11.2723 23.728 11.6405 23.728 12.0905C23.728 12.5405 23.3598 12.9086 22.9098 12.9086H13.0916C12.6416 12.9086 12.2734 12.5405 12.2734 12.0905C12.2734 11.6405 12.6416 11.2723 13.0916 11.2723H15.1371L15.718 10.6914C15.8653 10.5441 16.078 10.4541 16.2907 10.4541H19.7107C19.9234 10.4541 20.1362 10.5441 20.2834 10.6914ZM13.0916 23.545C13.0916 24.445 13.828 25.1814 14.728 25.1814H21.2734C22.1734 25.1814 22.9098 24.445 22.9098 23.545V15.3632C22.9098 14.4632 22.1734 13.7268 21.2734 13.7268H14.728C13.828 13.7268 13.0916 14.4632 13.0916 15.3632V23.545ZM15.5462 15.3632H20.4553C20.9053 15.3632 21.2734 15.7314 21.2734 16.1814V22.7268C21.2734 23.1768 20.9053 23.545 20.4553 23.545H15.5462C15.0962 23.545 14.728 23.1768 14.728 22.7268V16.1814C14.728 15.7314 15.0962 15.3632 15.5462 15.3632Z",
                    fill: "white"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 640,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("mask", {
                    id: "mask0_397_8210",
                    maskUnits: "userSpaceOnUse",
                    x: "12",
                    y: "10",
                    width: "12",
                    height: "16",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M20.2834 10.6914L20.8643 11.2723H22.9098C23.3598 11.2723 23.728 11.6405 23.728 12.0905C23.728 12.5405 23.3598 12.9086 22.9098 12.9086H13.0916C12.6416 12.9086 12.2734 12.5405 12.2734 12.0905C12.2734 11.6405 12.6416 11.2723 13.0916 11.2723H15.1371L15.718 10.6914C15.8653 10.5441 16.078 10.4541 16.2907 10.4541H19.7107C19.9234 10.4541 20.1362 10.5441 20.2834 10.6914ZM13.0916 23.545C13.0916 24.445 13.828 25.1814 14.728 25.1814H21.2734C22.1734 25.1814 22.9098 24.445 22.9098 23.545V15.3632C22.9098 14.4632 22.1734 13.7268 21.2734 13.7268H14.728C13.828 13.7268 13.0916 14.4632 13.0916 15.3632V23.545ZM15.5462 15.3632H20.4553C20.9053 15.3632 21.2734 15.7314 21.2734 16.1814V22.7268C21.2734 23.1768 20.9053 23.545 20.4553 23.545H15.5462C15.0962 23.545 14.728 23.1768 14.728 22.7268V16.1814C14.728 15.7314 15.0962 15.3632 15.5462 15.3632Z",
                        fill: "white"
                    }, void 0, false, {
                        fileName: "[project]/components/common/Icons.jsx",
                        lineNumber: 654,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 646,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    mask: "url(#mask0_397_8210)"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 661,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 632,
            columnNumber: 7
        }, this),
        saveAddress: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "36",
            viewBox: "0 0 36 36",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_4018_1111)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M18 36C27.9411 36 36 27.9411 36 18C36 8.05887 27.9411 0 18 0C8.05887 0 0 8.05887 0 18C0 27.9411 8.05887 36 18 36Z",
                            fill: "#4CAF50"
                        }, void 0, false, {
                            fileName: "[project]/components/common/Icons.jsx",
                            lineNumber: 673,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: "M22.8 9H13.2C12.5373 9 12 9.52491 12 10.1724V25.4138C12 25.4751 12.5373 26 13.2 26H22.8C23.4628 26 24 25.4751 24 25.4138V10.1724C24 9.52491 23.4628 9 22.8 9ZM15.6 10.1724H20.4V13.6897H15.6V10.1724ZM13.2 14.8621H22.8V24.2414H13.2V14.8621ZM16.8 17.2069H19.2V21.8966H16.8V17.2069Z",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/components/common/Icons.jsx",
                            lineNumber: 677,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 672,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_4018_1111",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "36",
                            height: "36",
                            fill: "white"
                        }, void 0, false, {
                            fileName: "[project]/components/common/Icons.jsx",
                            lineNumber: 684,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/common/Icons.jsx",
                        lineNumber: 683,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 682,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 665,
            columnNumber: 7
        }, this),
        minusCart: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "18",
            height: "4",
            viewBox: "0 0 18 4",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M17.335 2.24985C17.335 2.62568 17.1908 2.98898 16.9214 3.25206C16.6582 3.52141 16.2948 3.67174 15.9188 3.67174H10.2542H7.41568H1.75111C1.37514 3.67174 1.0117 3.52141 0.748525 3.25206C0.485348 2.98898 0.334961 2.62568 0.334961 2.24985C0.334961 1.87402 0.485348 1.51698 0.748525 1.24764C1.0117 0.98456 1.37514 0.834229 1.75111 0.834229H7.41568H10.2542H15.9188C16.2948 0.834229 16.6582 0.98456 16.9214 1.24764C17.1908 1.51698 17.335 1.87402 17.335 2.24985Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 697,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 690,
            columnNumber: 7
        }, this),
        plusCart: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "14",
            height: "15",
            viewBox: "0 0 14 15",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M14 8.49805H8V14.498H6V8.49805H0V6.49805H6V0.498047H8V6.49805H14V8.49805Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 711,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 704,
            columnNumber: 7
        }, this),
        removeCart: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M17.7147 17.7142L6.28613 6.28564M17.7147 6.28564L6.28613 17.7142",
                stroke: "#FF3131",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 725,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 718,
            columnNumber: 7
        }, this),
        locationShop: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "42",
            height: "42",
            viewBox: "0 0 42 42",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M21 42C32.598 42 42 32.598 42 21C42 9.40202 32.598 0 21 0C9.40202 0 0 9.40202 0 21C0 32.598 9.40202 42 21 42Z",
                    fill: "#CFFFE7"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 741,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M21.4993 10.916C17.7906 10.916 14.791 13.9156 14.791 17.6243C14.791 21.6206 19.0268 27.131 20.771 29.2298C21.1543 29.6898 21.8539 29.6898 22.2373 29.2298C23.9718 27.131 28.2077 21.6206 28.2077 17.6243C28.2077 13.9156 25.2081 10.916 21.4993 10.916ZM16.707 17.6237C16.707 14.9787 18.8537 12.832 21.4987 12.832C24.1437 12.832 26.2904 14.9787 26.2904 17.6237C26.2904 20.3837 23.5304 24.5141 21.4987 27.092C19.5054 24.5333 16.707 20.3549 16.707 17.6237ZM19.1035 17.6243C19.1035 18.9468 20.1768 20.0202 21.4993 20.0202C22.8218 20.0202 23.8952 18.9468 23.8952 17.6243C23.8952 16.3018 22.8218 15.2285 21.4993 15.2285C20.1768 15.2285 19.1035 16.3018 19.1035 17.6243Z",
                    fill: "#01BA5D"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 747,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("mask", {
                    id: "mask0_397_10920",
                    maskUnits: "userSpaceOnUse",
                    x: "14",
                    y: "10",
                    width: "15",
                    height: "20",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M21.4993 10.916C17.7906 10.916 14.791 13.9156 14.791 17.6243C14.791 21.6206 19.0268 27.131 20.771 29.2298C21.1543 29.6898 21.8539 29.6898 22.2373 29.2298C23.9718 27.131 28.2077 21.6206 28.2077 17.6243C28.2077 13.9156 25.2081 10.916 21.4993 10.916ZM16.707 17.6237C16.707 14.9787 18.8537 12.832 21.4987 12.832C24.1437 12.832 26.2904 14.9787 26.2904 17.6237C26.2904 20.3837 23.5304 24.5141 21.4987 27.092C19.5054 24.5333 16.707 20.3549 16.707 17.6237ZM19.1035 17.6243C19.1035 18.9468 20.1768 20.0202 21.4993 20.0202C22.8218 20.0202 23.8952 18.9468 23.8952 17.6243C23.8952 16.3018 22.8218 15.2285 21.4993 15.2285C20.1768 15.2285 19.1035 16.3018 19.1035 17.6243Z",
                        fill: "white"
                    }, void 0, false, {
                        fileName: "[project]/components/common/Icons.jsx",
                        lineNumber: 761,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 753,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    mask: "url(#mask0_397_10920)"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 768,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 734,
            columnNumber: 7
        }, this),
        imageUpload: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "23",
            viewBox: "0 0 24 23",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M14.875 17.25L10.1415 12.5165C9.58009 11.9551 8.66991 11.9551 8.10853 12.5165L4.39146 16.2335C3.48589 17.1391 1.9375 16.4977 1.9375 15.2171V2.875C1.9375 2.08109 2.58109 1.4375 3.375 1.4375H20.625C21.4189 1.4375 22.0625 2.08109 22.0625 2.875V17.25M12 14.375L15.296 11.079C15.8574 10.5176 16.7676 10.5176 17.329 11.079L21.6415 15.3915C21.911 15.661 22.0625 16.0267 22.0625 16.4079V20.125C22.0625 20.9189 21.4189 21.5625 20.625 21.5625H3.375C2.58109 21.5625 1.9375 20.9189 1.9375 20.125V17.25",
                    stroke: "black",
                    strokeWidth: "1.4375",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 779,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M7.6875 8.625C8.87836 8.625 9.84375 7.65961 9.84375 6.46875C9.84375 5.27789 8.87836 4.3125 7.6875 4.3125C6.49664 4.3125 5.53125 5.27789 5.53125 6.46875C5.53125 7.65961 6.49664 8.625 7.6875 8.625Z",
                    stroke: "black",
                    strokeWidth: "1.4375",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 786,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 772,
            columnNumber: 7
        }, this),
        nextMove: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "20",
            height: "16",
            viewBox: "0 0 20 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M19.7071 8.70711C20.0976 8.31658 20.0976 7.68342 19.7071 7.29289L13.3431 0.928932C12.9526 0.538408 12.3195 0.538408 11.9289 0.928932C11.5384 1.31946 11.5384 1.95262 11.9289 2.34315L17.5858 8L11.9289 13.6569C11.5384 14.0474 11.5384 14.6805 11.9289 15.0711C12.3195 15.4616 12.9526 15.4616 13.3431 15.0711L19.7071 8.70711ZM0 9H19V7H0V9Z",
                fill: "#01BE62"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 803,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 796,
            columnNumber: 7
        }, this),
        userProfile: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "40",
            height: "41",
            viewBox: "0 0 40 41",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20.4302 0.345703C16.5647 0.345703 12.7861 1.51868 9.57206 3.71631C6.35804 5.91394 3.85302 9.03751 2.37377 12.692C0.894516 16.3466 0.507476 20.3679 1.26159 24.2475C2.01571 28.1271 3.87711 31.6908 6.61041 34.4878C9.34371 37.2849 12.8261 39.1897 16.6173 39.9614C20.4085 40.7331 24.3382 40.337 27.9094 38.8233C31.4807 37.3095 34.533 34.7461 36.6806 31.4571C38.8281 28.1681 39.9744 24.3013 39.9744 20.3457C39.9689 15.0431 37.908 9.95926 34.244 6.20975C30.5799 2.46024 25.612 0.351303 20.4302 0.345703ZM10.2973 33.7111C11.3849 31.9705 12.8832 30.538 14.654 29.5458C16.4249 28.5536 18.4113 28.0335 20.4302 28.0335C22.4491 28.0335 24.4356 28.5536 26.2064 29.5458C27.9773 30.538 29.4755 31.9705 30.5631 33.7111C27.6659 36.0168 24.1004 37.2686 20.4302 37.2686C16.76 37.2686 13.1945 36.0168 10.2973 33.7111ZM14.4166 18.8072C14.4166 17.5901 14.7693 16.4003 15.4301 15.3883C16.0909 14.3764 17.0301 13.5876 18.1289 13.1218C19.2277 12.6561 20.4369 12.5342 21.6034 12.7716C22.7699 13.0091 23.8414 13.5952 24.6825 14.4558C25.5235 15.3164 26.0962 16.413 26.3282 17.6067C26.5603 18.8004 26.4412 20.0377 25.986 21.1622C25.5309 22.2867 24.7601 23.2478 23.7712 23.924C22.7822 24.6002 21.6196 24.9611 20.4302 24.9611C18.8353 24.9611 17.3057 24.3127 16.178 23.1587C15.0502 22.0046 14.4166 20.4393 14.4166 18.8072ZM32.7881 31.5784C31.1114 29.092 28.7537 27.1684 26.0116 26.0495C27.4846 24.8623 28.5594 23.2349 29.0866 21.3936C29.6139 19.5523 29.5673 17.5886 28.9534 15.7756C28.3394 13.9626 27.1887 12.3905 25.6612 11.2778C24.1336 10.1651 22.3052 9.5672 20.4302 9.5672C18.5552 9.5672 16.7268 10.1651 15.1993 11.2778C13.6717 12.3905 12.521 13.9626 11.9071 15.7756C11.2931 17.5886 11.2466 19.5523 11.7738 21.3936C12.301 23.2349 13.3759 24.8623 14.8489 26.0495C12.1067 27.1684 9.74901 29.092 8.07229 31.5784C5.95357 29.1402 4.56876 26.1273 4.08462 22.9024C3.60047 19.6775 4.03764 16.3782 5.34347 13.4017C6.6493 10.4251 8.76812 7.89835 11.4448 6.12558C14.1215 4.35281 17.2418 3.40964 20.4302 3.40964C23.6186 3.40964 26.739 4.35281 29.4156 6.12558C32.0923 7.89835 34.2111 10.4251 35.5169 13.4017C36.8228 16.3782 37.2599 19.6775 36.7758 22.9024C36.2917 26.1273 34.9068 29.1402 32.7881 31.5784Z",
                fill: "#01BA5D"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 817,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 810,
            columnNumber: 7
        }, this),
        shopkepperCarryBag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "25",
            height: "24",
            viewBox: "0 0 25 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("mask", {
                    id: "path-1-inside-1_397_11872",
                    fill: "white",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M12.5 18.5C10.16 18.5 8.25 16.59 8.25 14.25C8.25 13.84 8.59 13.5 9 13.5C9.41 13.5 9.75 13.84 9.75 14.25C9.75 15.77 10.98 17 12.5 17C14.02 17 15.25 15.77 15.25 14.25C15.25 13.84 15.59 13.5 16 13.5C16.41 13.5 16.75 13.84 16.75 14.25C16.75 16.59 14.84 18.5 12.5 18.5Z"
                    }, void 0, false, {
                        fileName: "[project]/components/common/Icons.jsx",
                        lineNumber: 832,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 831,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12.5 18.5C10.16 18.5 8.25 16.59 8.25 14.25C8.25 13.84 8.59 13.5 9 13.5C9.41 13.5 9.75 13.84 9.75 14.25C9.75 15.77 10.98 17 12.5 17C14.02 17 15.25 15.77 15.25 14.25C15.25 13.84 15.59 13.5 16 13.5C16.41 13.5 16.75 13.84 16.75 14.25C16.75 16.59 14.84 18.5 12.5 18.5Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 834,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12.5 17C10.9884 17 9.75 15.7616 9.75 14.25H6.75C6.75 17.4184 9.33157 20 12.5 20V17ZM9.75 14.25C9.75 14.6684 9.41843 15 9 15V12C7.76157 12 6.75 13.0116 6.75 14.25H9.75ZM9 15C8.58157 15 8.25 14.6684 8.25 14.25H11.25C11.25 13.0116 10.2384 12 9 12V15ZM8.25 14.25C8.25 16.5984 10.1516 18.5 12.5 18.5V15.5C11.8084 15.5 11.25 14.9416 11.25 14.25H8.25ZM12.5 18.5C14.8484 18.5 16.75 16.5984 16.75 14.25H13.75C13.75 14.9416 13.1916 15.5 12.5 15.5V18.5ZM16.75 14.25C16.75 14.6684 16.4184 15 16 15V12C14.7616 12 13.75 13.0116 13.75 14.25H16.75ZM16 15C15.5816 15 15.25 14.6684 15.25 14.25H18.25C18.25 13.0116 17.2384 12 16 12V15ZM15.25 14.25C15.25 15.7616 14.0116 17 12.5 17V20C15.6684 20 18.25 17.4184 18.25 14.25H15.25Z",
                    fill: "currentColor",
                    mask: "url(#path-1-inside-1_397_11872)"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 838,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M9.31968 1.99912L8.79 1.46945L9.31968 1.99912Z",
                    fill: "currentColor",
                    stroke: "currentColor",
                    strokeWidth: "1.5"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 843,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M19.31 6.37945C19.12 6.37945 18.93 6.30945 18.78 6.15945L15.15 2.52945C14.86 2.23945 14.86 1.75945 15.15 1.46945C15.44 1.17945 15.92 1.17945 16.21 1.46945L19.84 5.09945C20.13 5.38945 20.13 5.86945 19.84 6.15945C19.7 6.29945 19.5 6.37945 19.31 6.37945Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 849,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M20.71 10.5996C20.64 10.5996 20.57 10.5996 20.5 10.5996H20.27H4.5C3.8 10.6096 3 10.6096 2.42 10.0296C1.96 9.57961 1.75 8.87961 1.75 7.84961C1.75 5.09961 3.76 5.09961 4.72 5.09961H20.28C21.24 5.09961 23.25 5.09961 23.25 7.84961C23.25 8.88961 23.04 9.57961 22.58 10.0296C22.06 10.5496 21.36 10.5996 20.71 10.5996ZM4.72 9.09961H20.51C20.96 9.10961 21.38 9.10961 21.52 8.96961C21.59 8.89961 21.74 8.65961 21.74 7.84961C21.74 6.71961 21.46 6.59961 20.27 6.59961H4.72C3.53 6.59961 3.25 6.71961 3.25 7.84961C3.25 8.65961 3.41 8.89961 3.47 8.96961C3.61 9.09961 4.04 9.09961 4.48 9.09961H4.72Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 853,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M15.39 22.7507H9.36C5.78 22.7507 4.98 20.6207 4.67 18.7707L3.26 10.1207C3.19 9.71073 3.47 9.33073 3.88 9.26073C4.28 9.19073 4.67 9.47073 4.74 9.88073L6.15 18.5207C6.44 20.2907 7.04 21.2507 9.36 21.2507H15.39C17.96 21.2507 18.25 20.3507 18.58 18.6107L20.26 9.86073C20.34 9.45073 20.73 9.18073 21.14 9.27073C21.55 9.35073 21.81 9.74073 21.73 10.1507L20.05 18.9007C19.66 20.9307 19.01 22.7507 15.39 22.7507Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 857,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 824,
            columnNumber: 7
        }, this),
        shopkepperOption: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M2.75217 9.24783C2.95721 9.45287 3.19248 9.60774 3.45043 9.722C3.16687 9.59873 2.93469 9.43903 2.74783 9.25217C2.56097 9.06531 2.40127 8.83313 2.278 8.54957C2.39226 8.80752 2.54713 9.04279 2.75217 9.24783ZM2.75217 2.75217C2.54713 2.95721 2.39226 3.19248 2.27801 3.45043C2.40127 3.16686 2.56097 2.93469 2.74783 2.74783C2.93469 2.56097 3.16686 2.40127 3.45043 2.27801C3.19248 2.39226 2.95721 2.54713 2.75217 2.75217ZM9.24783 2.75217C9.04279 2.54713 8.80752 2.39226 8.54957 2.278C8.83313 2.40127 9.06531 2.56097 9.25217 2.74783C9.43903 2.93469 9.59873 3.16687 9.722 3.45043C9.60774 3.19248 9.45287 2.95721 9.24783 2.75217ZM9.24783 9.24783C9.45287 9.04279 9.60774 8.80752 9.722 8.54957C9.59873 8.83313 9.43903 9.06531 9.25217 9.25217C9.06531 9.43903 8.83313 9.59873 8.54957 9.722C8.80752 9.60774 9.04279 9.45287 9.24783 9.24783Z",
                    fill: "currentColor",
                    stroke: "currentColor",
                    strokeWidth: "1.5"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 871,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M14.7522 9.24783C14.9572 9.45287 15.1925 9.60774 15.4504 9.722C15.1669 9.59873 14.9347 9.43903 14.7478 9.25217C14.561 9.06531 14.4013 8.83313 14.278 8.54957C14.3923 8.80752 14.5471 9.04279 14.7522 9.24783ZM14.7522 2.75217C14.5471 2.95721 14.3923 3.19248 14.278 3.45043C14.4013 3.16686 14.561 2.93469 14.7478 2.74783C14.9347 2.56097 15.1669 2.40127 15.4504 2.27801C15.1925 2.39226 14.9572 2.54713 14.7522 2.75217ZM21.2478 2.75217C21.0428 2.54713 20.8075 2.39226 20.5496 2.278C20.8331 2.40127 21.0653 2.56097 21.2522 2.74783C21.439 2.93469 21.5987 3.16687 21.722 3.45043C21.6077 3.19248 21.4529 2.95721 21.2478 2.75217ZM21.2478 9.24783C21.4529 9.04279 21.6077 8.80752 21.722 8.54957C21.5987 8.83313 21.439 9.06531 21.2522 9.25217C21.0653 9.43903 20.8331 9.59873 20.5496 9.722C20.8075 9.60774 21.0428 9.45287 21.2478 9.24783Z",
                    fill: "currentColor",
                    stroke: "currentColor",
                    strokeWidth: "1.5"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 877,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M19 22.75H17C14.58 22.75 13.25 21.42 13.25 19V17C13.25 14.58 14.58 13.25 17 13.25H19C21.42 13.25 22.75 14.58 22.75 17V19C22.75 21.42 21.42 22.75 19 22.75ZM17 14.75C15.42 14.75 14.75 15.42 14.75 17V19C14.75 20.58 15.42 21.25 17 21.25H19C20.58 21.25 21.25 20.58 21.25 19V17C21.25 15.42 20.58 14.75 19 14.75H17Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 883,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M7 22.75H5C2.58 22.75 1.25 21.42 1.25 19V17C1.25 14.58 2.58 13.25 5 13.25H7C9.42 13.25 10.75 14.58 10.75 17V19C10.75 21.42 9.42 22.75 7 22.75ZM5 14.75C3.42 14.75 2.75 15.42 2.75 17V19C2.75 20.58 3.42 21.25 5 21.25H7C8.58 21.25 9.25 20.58 9.25 19V17C9.25 15.42 8.58 14.75 7 14.75H5Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 887,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 864,
            columnNumber: 7
        }, this),
        shopkepperWallet: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M6 8H10",
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 901,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M20.833 9H18.231C16.446 9 15 10.343 15 12C15 13.657 16.447 15 18.23 15H20.833C20.917 15 20.958 15 20.993 14.998C21.533 14.965 21.963 14.566 21.998 14.065C22 14.033 22 13.994 22 13.917V10.083C22 10.006 22 9.967 21.998 9.935C21.962 9.434 21.533 9.035 20.993 9.002C20.959 9 20.917 9 20.833 9Z",
                    stroke: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 907,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M20.965 9C20.887 7.128 20.637 5.98 19.828 5.172C18.657 4 16.771 4 13 4H10C6.229 4 4.343 4 3.172 5.172C2.001 6.344 2 8.229 2 12C2 15.771 2 17.657 3.172 18.828C4.344 19.999 6.229 20 10 20H13C16.771 20 18.657 20 19.828 18.828C20.637 18.02 20.888 16.872 20.965 15",
                    stroke: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 911,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M17.991 12H18.001",
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 915,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 894,
            columnNumber: 7
        }, this),
        shopkepperChartL: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "25",
            height: "24",
            viewBox: "0 0 25 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M2.5 22H22.5",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeMiterlimit: "10",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 931,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M10.25 4V22H14.75V4C14.75 2.9 14.3 2 12.95 2H12.05C10.7 2 10.25 2.9 10.25 4Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 939,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M3.5 10V22H7.5V10C7.5 8.9 7.1 8 5.9 8H5.1C3.9 8 3.5 8.9 3.5 10Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 946,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M17.5 15V22H21.5V15C21.5 13.9 21.1 13 19.9 13H19.1C17.9 13 17.5 13.9 17.5 15Z",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 953,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 924,
            columnNumber: 7
        }, this),
        shopkepperProfile: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "25",
            height: "24",
            viewBox: "0 0 25 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12.342 10.6197L12.4004 10.6217L12.4414 10.6135C12.4518 10.613 12.468 10.6125 12.4896 10.6125C12.534 10.6125 12.5887 10.6145 12.6412 10.6185L12.6718 10.6209L12.7025 10.6195C14.931 10.5171 16.6782 8.6862 16.6896 6.44253V6.44C16.6896 4.13386 14.8057 2.25 12.4996 2.25C10.1934 2.25 8.30957 4.13386 8.30957 6.44C8.30957 8.70956 10.0831 10.5402 12.342 10.6197ZM12.6596 11.12H12.6594H12.6592H12.659H12.6589H12.6587H12.6585H12.6583H12.6582H12.658H12.6578H12.6577H12.6575H12.6573H12.6571H12.657H12.6568H12.6566H12.6564H12.6563H12.6561H12.6559H12.6558H12.6556H12.6554H12.6552H12.6551H12.6549H12.6547H12.6546H12.6544H12.6542H12.6541H12.6539H12.6537H12.6536H12.6534H12.6532H12.653H12.6529H12.6527H12.6525H12.6524H12.6522H12.652H12.6519H12.6517H12.6515H12.6514H12.6512H12.651H12.6509H12.6507H12.6506H12.6504H12.6502H12.6501H12.6499H12.6497H12.6496H12.6494H12.6492H12.6491H12.6489H12.6487H12.6486H12.6484H12.6483H12.6481H12.6479H12.6478H12.6476H12.6475H12.6473H12.6471H12.647H12.6468H12.6466H12.6465H12.6463H12.6462H12.646H12.6458H12.6457H12.6455H12.6454H12.6452H12.645H12.6449H12.6447H12.6446H12.6444H12.6443H12.6441H12.6439H12.6438H12.6436H12.6435H12.6433H12.6431H12.643H12.6428H12.6427H12.6425H12.6424H12.6422H12.642H12.6419H12.6417H12.6416H12.6414H12.6413H12.6411H12.641H12.6408H12.6406H12.6405H12.6403H12.6402H12.64H12.6399H12.6397H12.6396H12.6394H12.6392H12.6391H12.6389H12.6388H12.6386H12.6385H12.6383H12.6382H12.638H12.6379H12.6377H12.6376H12.6374H12.6373H12.6371H12.6369H12.6368H12.6366H12.6365H12.6363H12.6362H12.636H12.6359H12.6357H12.6356H12.6354H12.6353H12.6351H12.635H12.6348H12.6347H12.6345H12.6344H12.6342H12.6341H12.6339H12.6338H12.6336H12.6335H12.6333H12.6332H12.633H12.6329H12.6327H12.6326H12.6324H12.6323H12.6321H12.632H12.6318H12.6317H12.6315H12.6314H12.6312H12.6311H12.6309H12.6308H12.6306H12.6305H12.6303H12.6302H12.63H12.6299H12.6297H12.6296H12.6294H12.6293H12.6291H12.629H12.6288H12.6287H12.6285H12.6284H12.6282H12.6281H12.6279H12.6278H12.6277H12.6275H12.6274H12.6272H12.6271H12.6269H12.6268H12.6266H12.6265H12.6263H12.6262H12.626H12.6259H12.6257H12.6256H12.6254H12.6253H12.6251H12.625H12.6249H12.6247H12.6246H12.6244H12.6243H12.6241H12.624H12.6238H12.6237H12.6235H12.6234H12.6232H12.6231H12.6229H12.6228H12.6226H12.6225H12.6224H12.6222H12.6221H12.6219H12.6218H12.6216H12.6215H12.6213H12.6212H12.621H12.6209H12.6207H12.6206H12.6204H12.6203H12.6202H12.62H12.6199H12.6197H12.6196H12.6194H12.6193H12.6191H12.619H12.6188H12.6187H12.6185H12.6184H12.6183H12.6181H12.618H12.6178H12.6177H12.6175H12.6175C12.5362 11.1098 12.452 11.1106 12.3754 11.1189C9.76221 11.0178 7.80957 8.96409 7.80957 6.44C7.80957 3.85614 9.91571 1.75 12.4996 1.75C15.0831 1.75 17.189 3.85562 17.1896 6.43903C17.1801 8.97998 15.1952 11.0348 12.6813 11.12H12.6813H12.6812H12.6812H12.6811H12.6811H12.681H12.681H12.6809H12.6808H12.6808H12.6807H12.6807H12.6806H12.6805H12.6805H12.6804H12.6804H12.6803H12.6803H12.6802H12.6801H12.6801H12.68H12.68H12.6799H12.6798H12.6798H12.6797H12.6797H12.6796H12.6796H12.6795H12.6794H12.6794H12.6793H12.6793H12.6792H12.6791H12.6791H12.679H12.679H12.6789H12.6788H12.6788H12.6787H12.6787H12.6786H12.6786H12.6785H12.6784H12.6784H12.6783H12.6783H12.6782H12.6781H12.6781H12.678H12.678H12.6779H12.6779H12.6778H12.6777H12.6777H12.6776H12.6776H12.6775H12.6774H12.6774H12.6773H12.6773H12.6772H12.6771H12.6771H12.677H12.677H12.6769H12.6769H12.6768H12.6767H12.6767H12.6766H12.6766H12.6765H12.6764H12.6764H12.6763H12.6763H12.6762H12.6762H12.6761H12.676H12.676H12.6759H12.6759H12.6758H12.6757H12.6757H12.6756H12.6756H12.6755H12.6754H12.6754H12.6753H12.6753H12.6752H12.6752H12.6751H12.675H12.675H12.6749H12.6749H12.6748H12.6747H12.6747H12.6746H12.6746H12.6745H12.6745H12.6744H12.6743H12.6743H12.6742H12.6742H12.6741H12.674H12.674H12.6739H12.6739H12.6738H12.6737H12.6737H12.6736H12.6736H12.6735H12.6735H12.6734H12.6733H12.6733H12.6732H12.6732H12.6731H12.673H12.673H12.6729H12.6729H12.6728H12.6728H12.6727H12.6726H12.6726H12.6725H12.6725H12.6724H12.6723H12.6723H12.6722H12.6722H12.6721H12.6721H12.672H12.6719H12.6719H12.6718H12.6718H12.6717H12.6716H12.6716H12.6715H12.6715H12.6714H12.6713H12.6713H12.6712H12.6712H12.6711H12.6711H12.671H12.6709H12.6709H12.6708H12.6708H12.6707H12.6706H12.6706H12.6705H12.6705H12.6704H12.6704H12.6703H12.6702H12.6702H12.6701H12.6701H12.67H12.6699H12.6699H12.6698H12.6698H12.6697H12.6696H12.6696H12.6695H12.6695H12.6694H12.6694H12.6693H12.6692H12.6692H12.6691H12.6691H12.669H12.6689H12.6689H12.6688H12.6688H12.6687H12.6687H12.6686H12.6685H12.6685H12.6684H12.6684H12.6683H12.6682H12.6682H12.6681H12.6681H12.668H12.6679H12.6679H12.6678H12.6678H12.6677H12.6677H12.6676H12.6675H12.6675H12.6674H12.6674H12.6673H12.6672H12.6672H12.6671H12.6671H12.667H12.667H12.6669H12.6668H12.6668H12.6667H12.6667H12.6666H12.6665H12.6665H12.6664H12.6664H12.6663H12.6662H12.6662H12.6661H12.6661H12.666H12.666H12.6659H12.6658H12.6658H12.6657H12.6657H12.6656H12.6655H12.6655H12.6654H12.6654H12.6653H12.6653H12.6652H12.6651H12.6651H12.665H12.665H12.6649H12.6648H12.6648H12.6647H12.6647H12.6646H12.6646H12.6645H12.6644H12.6644H12.6643H12.6643H12.6642H12.6641H12.6641H12.664H12.664H12.6639H12.6638H12.6638H12.6637H12.6637H12.6636H12.6636H12.6635H12.6634H12.6634H12.6633H12.6633H12.6632H12.6631H12.6631H12.663H12.663H12.6629H12.6629H12.6628H12.6627H12.6627H12.6626H12.6626H12.6625H12.6624H12.6624H12.6623H12.6623H12.6622H12.6621H12.6621H12.662H12.662H12.6619H12.6619H12.6618H12.6617H12.6617H12.6616H12.6616H12.6615H12.6614H12.6614H12.6613H12.6613H12.6612H12.6612H12.6611H12.661H12.661H12.6609H12.6609H12.6608H12.6607H12.6607H12.6606H12.6606H12.6605H12.6604H12.6604H12.6603H12.6603H12.6602H12.6602H12.6601H12.66H12.66H12.6599H12.6599H12.6598H12.6597H12.6597H12.6596H12.6596Z",
                    fill: "currentColor",
                    stroke: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 970,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12.6696 22.55C10.7096 22.55 8.73961 22.05 7.24961 21.05C5.85961 20.13 5.09961 18.87 5.09961 17.5C5.09961 16.13 5.85961 14.86 7.24961 13.93C10.2496 11.94 15.1096 11.94 18.0896 13.93C19.4696 14.85 20.2396 16.11 20.2396 17.48C20.2396 18.85 19.4796 20.12 18.0896 21.05C16.5896 22.05 14.6296 22.55 12.6696 22.55ZM8.07961 15.19C7.11961 15.83 6.59961 16.65 6.59961 17.51C6.59961 18.36 7.12961 19.18 8.07961 19.81C10.5696 21.48 14.7696 21.48 17.2596 19.81C18.2196 19.17 18.7396 18.35 18.7396 17.49C18.7396 16.64 18.2096 15.82 17.2596 15.19C14.7696 13.53 10.5696 13.53 8.07961 15.19Z",
                    fill: "currentColor"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 975,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 963,
            columnNumber: 7
        }, this),
        plusGreen: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "32",
            height: "32",
            viewBox: "0 0 32 32",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M8 16H24",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 989,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16 24V8",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 996,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 982,
            columnNumber: 7
        }, this),
        arrowNext: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M8.90991 19.9201L15.4299 13.4001C16.1999 12.6301 16.1999 11.3701 15.4299 10.6001L8.90991 4.08008",
                stroke: "#228B22",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }, void 0, false, {
                fileName: "[project]/components/common/Icons.jsx",
                lineNumber: 1013,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 1006,
            columnNumber: 7
        }, this),
        greenEye: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "22",
            height: "23",
            viewBox: "0 0 22 23",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M13.9893 11.2848C13.9893 13.0627 12.5527 14.4993 10.7748 14.4993C8.99695 14.4993 7.5603 13.0627 7.5603 11.2848C7.5603 9.50696 8.99695 8.07031 10.7748 8.07031C12.5527 8.07031 13.9893 9.50696 13.9893 11.2848Z",
                    stroke: "#01BE62",
                    "stroke-width": "1.34686",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 1031,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M10.7748 18.71C13.9444 18.71 16.8985 16.8423 18.9547 13.6098C19.7628 12.3438 19.7628 10.2158 18.9547 8.94971C16.8985 5.71725 13.9444 3.84961 10.7748 3.84961C7.60517 3.84961 4.65106 5.71725 2.59486 8.94971C1.78674 10.2158 1.78674 12.3438 2.59486 13.6098C4.65106 16.8423 7.60517 18.71 10.7748 18.71Z",
                    stroke: "#01BE62",
                    "stroke-width": "1.34686",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 1038,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 1024,
            columnNumber: 7
        }, this),
        transitionCome: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M22 2L13.8 10.2",
                    stroke: "#228B22",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 1055,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M13 6.16992V10.9999H17.83",
                    stroke: "#228B22",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 1062,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13",
                    stroke: "#228B22",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }, void 0, false, {
                    fileName: "[project]/components/common/Icons.jsx",
                    lineNumber: 1069,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/Icons.jsx",
            lineNumber: 1048,
            columnNumber: 7
        }, this)
    };
    return icon && iconsList[icon];
};
_c = Icon;
const __TURBOPACK__default__export__ = Icon;
var _c;
__turbopack_context__.k.register(_c, "Icon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/UpiButton.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/Icons.jsx [app-client] (ecmascript)");
'use client';
;
;
;
const UpiButton = ()=>{
    const handleUPIClick = ()=>{
        const upiId = 'ks3399094@okhdcbank'; // Replace with your UPI ID
        const payeeName = 'Keshav Kumar';
        const amount = '100'; // Change amount as needed
        const note = 'Test Payment';
        const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}`;
        // Redirect to UPI payment app
        window.location.href = upiUrl;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: handleUPIClick,
        className: "bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700 transition",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            icon: "scaner"
        }, void 0, false, {
            fileName: "[project]/components/common/UpiButton.jsx",
            lineNumber: 26,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/common/UpiButton.jsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
};
_c = UpiButton;
const __TURBOPACK__default__export__ = UpiButton;
var _c;
__turbopack_context__.k.register(_c, "UpiButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/BottomBar.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/helper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/Icons.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$UpiButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/UpiButton.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const BottomBar = ()=>{
    _s();
    const pathName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-[59px] max-w-[540px] mx-auto bg-white rounded-t-lg py-4 z-10 w-full fixed shadow-bottom-bar left-1/2 -translate-x-1/2 bottom-0",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-10 items-center justify-between px-4",
            children: [
                __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BOTTOM_BAR_LIST"].map((obj, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: obj.path,
                        className: `text-black hover:text-greens-900 duration-300 ${obj.path === pathName && "text-greens-900"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            icon: obj.icon
                        }, void 0, false, {
                            fileName: "[project]/components/common/BottomBar.jsx",
                            lineNumber: 22,
                            columnNumber: 13
                        }, this)
                    }, i, false, {
                        fileName: "[project]/components/common/BottomBar.jsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, this)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$UpiButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/components/common/BottomBar.jsx",
                    lineNumber: 25,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/common/BottomBar.jsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/common/BottomBar.jsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
};
_s(BottomBar, "28xf+Q/MMfpBebWfp+J7Y3ZZbws=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = BottomBar;
const __TURBOPACK__default__export__ = BottomBar;
var _c;
__turbopack_context__.k.register(_c, "BottomBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/customer/HeaderCustomer.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/Icons.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const HeaderCustomer = ({ name, location, classCard })=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `pt-[50px] pb-4 h-[176px] rounded-b-3xl  bg-greens-900 px-4 ${classCard}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>router.back(),
                        className: "border-0 outline-0 bg-transparent",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            icon: "back",
                            className: "invert"
                        }, void 0, false, {
                            fileName: "[project]/components/customer/HeaderCustomer.jsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/customer/HeaderCustomer.jsx",
                        lineNumber: 14,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/customer",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/assets/images/svg/logo.svg",
                            width: 86,
                            height: 39,
                            sizes: "100vw",
                            className: "w-[85px] h-[32px] object-cover",
                            alt: "logo"
                        }, void 0, false, {
                            fileName: "[project]/components/customer/HeaderCustomer.jsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/customer/HeaderCustomer.jsx",
                        lineNumber: 20,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/customer/HeaderCustomer.jsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `mt-2 ${!location && "!mt-8"}`,
                children: [
                    location && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-1.5 text-white items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$Icons$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                icon: "locationWhite"
                            }, void 0, false, {
                                fileName: "[project]/components/customer/HeaderCustomer.jsx",
                                lineNumber: 34,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-lg text-white font-semibold !leading-130",
                                children: "Dhaka, Banassre"
                            }, void 0, false, {
                                fileName: "[project]/components/customer/HeaderCustomer.jsx",
                                lineNumber: 35,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/customer/HeaderCustomer.jsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl mt-2 capitalize font-semibold  font-roboto text-white !leading-130",
                        children: name
                    }, void 0, false, {
                        fileName: "[project]/components/customer/HeaderCustomer.jsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/customer/HeaderCustomer.jsx",
                lineNumber: 31,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/customer/HeaderCustomer.jsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_s(HeaderCustomer, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = HeaderCustomer;
const __TURBOPACK__default__export__ = HeaderCustomer;
var _c;
__turbopack_context__.k.register(_c, "HeaderCustomer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/utils/jwt.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "decodeToken": (()=>decodeToken)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jwt$2d$decode$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jwt-decode/build/esm/index.js [app-client] (ecmascript)");
;
const decodeToken = (token)=>{
    try {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jwt$2d$decode$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jwtDecode"])(token);
    } catch (error) {
        console.error("Invalid token", error);
        return null;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/services/auth.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "authType": (()=>authType),
    "getToken": (()=>getToken),
    "getUserFromToken": (()=>getUserFromToken),
    "getUserId": (()=>getUserId),
    "isAdmin": (()=>isAdmin),
    "isAuthenticated": (()=>isAuthenticated),
    "login": (()=>login),
    "logout": (()=>logout),
    "register": (()=>register),
    "removeToken": (()=>removeToken),
    "saveToken": (()=>saveToken),
    "verifyOtp": (()=>verifyOtp)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/axiosInstance.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$jwt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/jwt.js [app-client] (ecmascript)");
;
;
;
const TOKEN_KEY = 'token';
const login = async (email, password)=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/auth/login', {
        email,
        password
    });
    return res.data;
};
const register = async (data)=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/auth/register', data);
    return res.data;
};
const verifyOtp = async (data)=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/verify-otp', data);
    return res.data;
};
const saveToken = (token)=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(TOKEN_KEY, token, {
        secure: true,
        sameSite: 'Strict',
        expires: 7
    }); // Expires in 7 days
};
const getToken = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(TOKEN_KEY);
};
const removeToken = ()=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove(TOKEN_KEY);
};
const getUserFromToken = ()=>{
    const token = getToken();
    console.log(token, "token in auth service");
    if (!token) return null;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$jwt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeToken"])(token);
};
const isAuthenticated = ()=>{
    const user = getUserFromToken();
    return !!user;
};
const authType = ()=>{
    return getUserFromToken()?.authType;
};
const getUserId = ()=>{
    return getUserFromToken()?.userId;
};
const isAdmin = ()=>{
    return getUserFromToken()?.isAdmin;
};
const logout = ()=>{
    const userRole = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("userRole");
    // Remove cookies
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove("token");
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove("userId");
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove("userRole");
    // Redirect based on role
    switch(userRole){
        case "admin":
            window.location.href = "/sign-in?auth=admin";
            break;
        case "shopkeeper":
            window.location.href = "/sign-in?auth=shopkeeper";
            break;
        case "customer":
            window.location.href = "/sign-in?auth=customer";
            break;
        default:
            window.location.href = "/sign-in";
            break;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/services/axiosInstance.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/auth.service.js [app-client] (ecmascript)");
;
;
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: ("TURBOPACK compile-time value", "https://api.sowpaymart.com/"),
    headers: {
        'Content-Type': 'application/json'
    }
});
const __TURBOPACK__default__export__ = api;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/services/basic-details.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "deleteBasicDetails": (()=>deleteBasicDetails),
    "getAllBasicDetails": (()=>getAllBasicDetails),
    "getBasicDetails": (()=>getBasicDetails),
    "submitBasicDetails": (()=>submitBasicDetails),
    "updateBasicDetails": (()=>updateBasicDetails)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/axiosInstance.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-client] (ecmascript)");
;
;
const userId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('userId');
const submitBasicDetails = async (details)=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/basic-details', details);
    return res.data;
};
const getAllBasicDetails = async ()=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/api/basic-details`);
    return res.data;
};
const getBasicDetails = async (id)=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/api/basic-details/${id}`);
    return res.data;
};
const updateBasicDetails = async (updatedDetails)=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/api/basic-details/${userId}`, updatedDetails);
    return res.data;
};
const deleteBasicDetails = async ()=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/api/basic-details/${userId}`);
    return res.data;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/common/CustomButton.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CustomButton": (()=>CustomButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
const CustomButton = ({ children, customClass, url, isSubmit, onClick })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: url ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: `p-2.5 block overflow-hidden rounded custom_button text-white font-medium text-base !leading-130 ${customClass}`,
            href: url,
            onClick: onClick,
            "aria-label": "link",
            children: children
        }, void 0, false, {
            fileName: "[project]/components/common/CustomButton.jsx",
            lineNumber: 13,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: `p-2.5 block overflow-hidden rounded custom_button text-white font-medium text-base !leading-130 ${customClass}`,
            onClick: onClick,
            type: isSubmit ? "submit" : "button",
            children: children
        }, void 0, false, {
            fileName: "[project]/components/common/CustomButton.jsx",
            lineNumber: 22,
            columnNumber: 9
        }, this)
    }, void 0, false);
};
_c = CustomButton;
var _c;
__turbopack_context__.k.register(_c, "CustomButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/services/payment.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createPayment": (()=>createPayment),
    "deleteProduct": (()=>deleteProduct),
    "getAllPayments": (()=>getAllPayments),
    "getPaymentById": (()=>getPaymentById),
    "getPaymenttByUserId": (()=>getPaymenttByUserId),
    "updateProduct": (()=>updateProduct)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/axiosInstance.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/js-cookie/dist/js.cookie.mjs [app-client] (ecmascript)");
;
;
const token = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$js$2d$cookie$2f$dist$2f$js$2e$cookie$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("token");
const getAllPayments = async ()=>{
    const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/api/payments`, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    return res.data;
};
const getPaymentById = async (id)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/api/payment/${id}`);
    return response.data;
};
const getPaymenttByUserId = async (id)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/api/payment/user/${id}`);
    return response.data;
};
const createPayment = async (data)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/api/payment', data, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    return response.data;
};
const updateProduct = async (id, data)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/api/payment/${id}`, data, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    return response.data;
};
const deleteProduct = async (id)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$axiosInstance$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/api/payment/${id}`);
    return response.data;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/(pannel)/customer/shop/[userId]/page.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$BottomBar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/BottomBar.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$customer$2f$HeaderCustomer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/customer/HeaderCustomer.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$basic$2d$details$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/basic-details.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$CustomButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/common/CustomButton.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/dialog/dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$payment$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/payment.service.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client"; // 👈 Add this as the first line
;
;
;
;
;
;
;
;
const Page = ()=>{
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const userId = searchParams.get(3);
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [amount, setAmount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const handleSubmit = async ()=>{
        const value = parseFloat(amount);
        const token = localStorage.getItem("token"); // Or get from context/store
        if (isNaN(value)) {
            setError("Please enter a valid number.");
        } else if (value > 5000) {
            setError("Amount should not exceed ₹5000.");
        } else if (value <= 0) {
            setError("Amount must be greater than 0.");
        } else {
            setError("");
            try {
                const data = {
                    amount: value,
                    userId: 1,
                    userName: 'sunil',
                    status: "pending",
                    transactionId: 3,
                    totalAmount: value,
                    earnAmount: value * .10,
                    paymentMethod: 'online'
                };
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$payment$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPayment"])(data, token);
                console.log("Payment successful:", result);
                alert(`Paying ₹${amount}`);
                setIsOpen(false);
                setAmount("");
            } catch (error) {
                console.error("Payment failed:", error);
                setError("Payment failed. Please try again.");
            }
        }
    };
    const [shopDetails, setShopDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Page.useEffect": ()=>{
            // if (!userId) return;
            console.log("Fetching shop details for userId:", userId);
            const fetchShopDetails = {
                "Page.useEffect.fetchShopDetails": async ()=>{
                    try {
                        const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$basic$2d$details$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBasicDetails"])(60);
                        setShopDetails(response || null);
                    } catch (error) {
                        console.error("Error fetching shop details:", error);
                    } finally{
                        setLoading(false);
                    }
                }
            }["Page.useEffect.fetchShopDetails"];
            fetchShopDetails();
        }
    }["Page.useEffect"], [
        userId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white-low",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$customer$2f$HeaderCustomer$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                name: "Shop Details"
            }, void 0, false, {
                fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 pb-20 pt-8",
                children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-500",
                    children: "Loading..."
                }, void 0, false, {
                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                    lineNumber: 76,
                    columnNumber: 11
                }, this) : !shopDetails ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-red-500",
                    children: "No shop data found for this user."
                }, void 0, false, {
                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                    lineNumber: 78,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white p-6 rounded-lg shadow border border-gray-200 space-y-3 text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Username",
                                    value: shopDetails.username
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Shop Name",
                                    value: shopDetails.shopname
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 83,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Category",
                                    value: shopDetails.category
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "SMP",
                                    value: shopDetails.smp
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 85,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "GST Number",
                                    value: shopDetails.gst_number
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 86,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Pincode",
                                    value: shopDetails.pincode
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 87,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Village",
                                    value: shopDetails.village
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 88,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "City",
                                    value: shopDetails.city
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 89,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "District",
                                    value: shopDetails.district
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "State",
                                    value: shopDetails.state
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 91,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Latitude",
                                    value: shopDetails.latitude
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Longitude",
                                    value: shopDetails.longitude
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 93,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Created At",
                                    value: new Date(shopDetails.createdAt).toLocaleString()
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Updated At",
                                    value: new Date(shopDetails.updatedAt).toLocaleString()
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Detail, {
                                    label: "Address",
                                    value: shopDetails.address,
                                    full: true
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 96,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                            lineNumber: 81,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: shopDetails.qrCode
                            }, void 0, false, {
                                fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                lineNumber: 99,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$CustomButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomButton"], {
                            url: "#",
                            customClass: "mt-2 w-fit text-sm w-full text-center",
                            onClick: (e)=>{
                                e.preventDefault();
                                setIsOpen(true);
                            },
                            children: "Pay"
                        }, void 0, false, {
                            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                    lineNumber: 80,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
                open: isOpen,
                onClose: ()=>setIsOpen(false),
                className: "relative z-50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 bg-black/30",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 flex items-center justify-center p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"].Panel, {
                            className: "w-full max-w-md bg-white rounded-lg p-6 shadow-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$dialog$2f$dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"].Title, {
                                    className: "text-lg font-semibold text-gray-800 mb-4",
                                    children: "Enter Payment Amount"
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 119,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    placeholder: "Amount",
                                    value: amount,
                                    onChange: (e)=>setAmount(e.target.value),
                                    className: "w-full px-4 py-2 border rounded-md mb-4 focus:outline-none focus:ring focus:border-blue-300"
                                }, void 0, false, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-end gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$CustomButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomButton"], {
                                            onClick: ()=>setIsOpen(false),
                                            className: "px-4 py-2 rounded-md !bg-transparent !text-[#01be62] hover:!bg-gray-100",
                                            children: "Cancel"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$CustomButton$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomButton"], {
                                            onClick: handleSubmit,
                                            className: "px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white",
                                            children: "Submit"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                            lineNumber: 138,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                                    lineNumber: 131,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                            lineNumber: 118,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                lineNumber: 115,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$common$2f$BottomBar$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                lineNumber: 149,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
};
_s(Page, "q7SRP6G9q56vaI8cV6B/mGrgQOI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = Page;
const Detail = ({ label, value, full = false })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: full ? "col-span-full" : "",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-gray-600",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "font-medium text-gray-800",
                    children: [
                        label,
                        ":"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                    lineNumber: 157,
                    columnNumber: 7
                }, this),
                " ",
                value || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-gray-400 italic",
                    children: "N/A"
                }, void 0, false, {
                    fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
                    lineNumber: 158,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
            lineNumber: 156,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(pannel)/customer/shop/[userId]/page.jsx",
        lineNumber: 155,
        columnNumber: 3
    }, this);
_c1 = Detail;
const __TURBOPACK__default__export__ = Page;
var _c, _c1;
__turbopack_context__.k.register(_c, "Page");
__turbopack_context__.k.register(_c1, "Detail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_8af4bcaa._.js.map