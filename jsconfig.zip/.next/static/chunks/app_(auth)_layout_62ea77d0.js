(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_layout_62ea77d0.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_layout_62ea77d0.js",
  "chunks": [
    "static/chunks/components_7689b52c._.js",
    "static/chunks/node_modules_next_f5074bf6._.js"
  ],
  "source": "dynamic"
});
