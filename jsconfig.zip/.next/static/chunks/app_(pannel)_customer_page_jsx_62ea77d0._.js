(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(pannel)_customer_page_jsx_62ea77d0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(pannel)_customer_page_jsx_62ea77d0._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ed9b23f8._.js",
    "static/chunks/_a6b05e21._.js",
    "static/chunks/node_modules_746b2922._.js",
    "static/chunks/node_modules_swiper_55025702._.css"
  ],
  "source": "dynamic"
});
